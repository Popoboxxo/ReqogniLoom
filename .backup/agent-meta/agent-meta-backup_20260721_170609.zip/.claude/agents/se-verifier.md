---
name: se-verifier
description: Agent for ReqFlow.
model: claude-sonnet-5
memory: project
---
