# Memory Index

- [REQ-066 Service-Layer-Grenzen](project_req-066-service-layer.md) — kein Repository-Pattern existiert; ORM-in-Service ist Konvention; A-16 ist der harte Verstoß
