---
name: project_req178_187_permission_workflow_global_default
description: REQ-178..187 global-default workflow/permission model + Settings IA split — validation outcome and where the security-sensitive seam lives
metadata:
  type: project
---

REQ-178 through REQ-187 (docs/REQUIREMENTS.md, section "Workflow & Permissions:
Global-Default-Modell + Settings-IA-Split", added 2026-07-18) introduce a
symmetric global-default → workspace-override → reset model for both Workflow
Definitions (REQ-178-180) and Permissions (REQ-181-183), plus a Settings IA
split into Workspace Settings vs. System Settings (REQ-184-185). REQ-186/187
go further for permissions: the new model is meant to REPLACE the hardcoded
`UserRole`/`ItemPermission` enforcement as the sole authoritative access-control
decision — not just exist alongside it.

Validated 2026-07-18 (branch `feat/ux-review-workflow-editor`, all APPROVED_WITH_NOTES,
pre-commit): the rollout is wired safely — `GlobalPermissionDefinition.enforcement_mode`
defaults to `shadow`, and the shadow-verify seam
(`backend/auth_tenancy/services/permission_shadow.py::shadow_decide`) only lets
the new permission_json model govern real access when a tenant has been
explicitly flipped to `authoritative` via the guarded
`POST /permission-defaults/enforcement/flip/` endpoint (exact pending-mismatch-count
echo required for shadow→authoritative; audited). Any internal error in the
shadow path fails closed to the legacy decision — confirmed as a hard, tested
invariant, not just a docstring claim.

**Why this matters for future work:** the actual authoritative cutover (flipping
a real tenant from shadow to authoritative) has NOT happened yet as of this
validation — REQ-186's full acceptance criterion ("no access decision relies on
the legacy check") is not yet met tenant-wide, by design (REQ-187's safe-rollout
requirement). Future validator passes touching `auth_tenancy` or
`rest_api/auth_enforcer.py` should re-check `shadow_decide` and the flip guard
haven't been weakened, since this is the single seam that could turn a routine
permission-matrix edit into a live access-control change.

**How to apply:** if a future task references "the permission cutover" or asks
whether the new model is live, check `GlobalPermissionDefinition.enforcement_mode`
per-tenant rather than assuming from the presence of the model alone — schema
existing does not mean it's authoritative.
