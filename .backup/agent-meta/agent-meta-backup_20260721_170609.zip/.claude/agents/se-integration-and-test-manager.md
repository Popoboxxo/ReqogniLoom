---
name: se-integration-and-test-manager
description: Agent for ReqFlow.
model: claude-sonnet-5
---
