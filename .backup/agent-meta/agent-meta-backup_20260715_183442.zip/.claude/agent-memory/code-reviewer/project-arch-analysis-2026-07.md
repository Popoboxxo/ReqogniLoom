---
name: project-arch-analysis-2026-07
description: Key non-obvious findings from 2026-07-14 deep architecture analysis (beyond SYSTEM_AUDIT.md) — outbox poller unwired, no CACHES config, list-materialization pattern
metadata:
  type: project
---

Deep architecture analysis (2026-07-14) found gaps NOT in docs/se/SYSTEM_AUDIT.md. The non-obvious ones worth re-checking in future reviews:

- **Outbox poller never wired:** `application/event_bus.py::poll_and_dispatch()` has no Celery task, no beat schedule, no management command calling it. Audit fixes S-01/S-02 (REQ-020/021) are "Done" but the code never runs in deployment. Also: subscriber dispatch runs INSIDE the row-lock transaction.
- **Django CACHES unconfigured** in `reqflow/settings.py` — root cause of audit X-02/S-15/P-12 (four ad-hoc in-process caches).
- **Systemic list materialization:** `BaseEntityViewSet._paginate(request, data: list)` (rest_api/views.py:160) paginates fully serialized Python lists — every list endpoint is O(N), not just search (audit S-14 understates this).
- **pytest runs on prod settings** (`pyproject.toml` points at `reqflow.settings`, not `settings_test`); `factory-boy` declared but never used.
- Tracked scratch files at backend root: `admin_test_tmp.py`, `fix_admin.py` (mass-edits admin.py files!), `seed_toothbrush.py`.

**Why:** These are false-confidence traps — audit says "Done" on event-bus fixes but runtime path is dead; future reviews of event/webhook features must verify the consumer exists.
**How to apply:** When reviewing changes touching event_bus, webhooks, caching, or list endpoints, check these structural gaps first before assessing the diff in isolation.
