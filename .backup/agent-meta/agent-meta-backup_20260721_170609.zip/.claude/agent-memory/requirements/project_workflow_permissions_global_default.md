---
name: project-workflow-permissions-global-default
description: Kontext zu REQ-178–187 (Global-Default + Workspace-Override + Reset für Workflows & Permissions, Settings-IA-Split, Permission-Modernisierung/Legacy-Ablösung)
metadata:
  type: project
---

Am 2026-07-18 wurden REQ-178 bis REQ-185 in docs/REQUIREMENTS.md erfasst, ausgelöst durch
Nutzer-Feedback zum read-only Workflow-Editor (REQ-176/177): "das Datenmodell ist falsch" —
`WorkflowDefinition` lebt nur workspace-scoped (`backend/workflow/models.py:83`), kein
tenant-weiter Default, keine Vererbung, kein Reset.

Bestätigter Scope (vom Nutzer final entschieden, nicht mehr offen):
- REQ-178/179/180: Workflows — globaler Default, Workspace-Override bleibt voll editierbar
  (Wiederverwendung der Editor-Mutationslogik aus REQ-177), Reset-to-Default mit
  on-default/customized-Unterscheidung.
- REQ-181/182/183: Berechtigungen bekommen SYMMETRISCH dasselbe Modell (war offene Frage,
  jetzt mit Ja beantwortet — nicht workspace-only).
- REQ-184: Settings-IA-Split — neuer Top-Level-Nav-Eintrag "System Settings" mit eigener
  Route (z.B. /system-settings); Workspace-Settings bleiben unter bestehender Route.
  Nur IA-Split, kein visuelles Redesign.
- REQ-185: Governance-Tab ("Workflows & Berechtigungen" in WorkspaceSettings.tsx:295,
  WorkflowsSection.tsx + PermissionsSection) muss dismantled/umgebaut werden — als
  betroffener Scope geflaggt, konkretes UI-Redesign explizit NICHT hier entschieden
  (Aufgabe des ui-ux-designer in späterem Schritt).

Pipeline (7 Schritte): requirements (fertig) → database-engineer → api-specialist →
ui-ux-designer → senior-developer → validator → git. Branch: `feat/ux-review-workflow-editor`
(Nutzer hat bewusst entschieden, nicht abzuzweigen, obwohl anderer Scope als REQ-176).

Existierende, teils überlappende Vorläufer-Requirements: REQ-166 (entitätstyp-spezifische
Presets), REQ-172 (per-Transition change_reason + globale Defaults/Override/Reset — bereits
im Beschreibungstext angedeutet, aber nicht umgesetzt, Status "Proposed"), REQ-174
(Workflow-Settings-UI-Redesign, Status "Proposed"). REQ-178–180 verfeinern/konkretisieren
diese für das Datenmodell explizit; REQ-172/174 bleiben in der Datei stehen (nicht ersetzt,
nur referenziert via Abhängigkeit).

**Why:** Damit nachfolgende Agenten (database-engineer, api-specialist, ui-ux-designer,
senior-developer) den vollen Entscheidungskontext haben, ohne den Chat-Verlauf erneut lesen
zu müssen.

**How to apply:** Bei Folgearbeiten an REQ-178–185 immer prüfen, ob REQ-166/172/174 durch die
Umsetzung obsolet werden oder als Status auf "Superseded" gesetzt werden sollten — das ist
eine Entscheidung für einen späteren Requirements-Durchlauf, nicht automatisch hier vorwegnehmen.

## Revision 2026-07-18 (nach database-engineer-Review): Eskalation additiv → autoritative Ablösung

Ein database-engineer-Pass auf dem Schema deckte auf, dass die reale Permission-Enforcement
heute ausschließlich über hartkodierte `UserRole`/`ItemPermission`-Prüfungen läuft
(COMP-AT-002 AuthorizationService, `backend/auth_tenancy`) — unabhängig vom neuen
Global/Override/Reset-permission_json-Modell, das ursprünglich additiv (Governance-/
Anzeige-Schicht NEBEN der bestehenden Durchsetzung) konzipiert war (siehe ursprüngliche
REQ-181 Beschreibung).

Nutzer-Entscheidung (wörtlich): "UserRole und ItemPermission ist mir ein Dorn im Auge!
Das muss modernisiert werden! Daher sauber die Permissions umbauen!" — das neue Modell
MUSS die reale, autoritative Durchsetzung werden und die hartkodierten Prüfungen ABLÖSEN,
nicht nur ergänzen. Nutzer akzeptiert den dadurch stark erhöhten Blast-Radius (live
Zugriffskontrolle der gesamten App), verlangt aber explizit einen sicheren Rollout-Pfad
(z.B. Dual-Write/Shadow-Verify vor Cutover — HOW ist NICHT Teil der Requirements, das ist
database-engineer/senior-developer-Aufgabe) statt stillem Hard-Cutover, mit sichtbarem statt
verstecktem Regressionsrisiko.

Ergebnis dieser Revision in docs/REQUIREMENTS.md:
- **REQ-178** überarbeitet: globaler Workflow-Default gilt jetzt EXPLIZIT je Rigor-Preset
  (Minimal/Standard/Extended) separat, nicht presetübergreifend geteilt — on-default/
  customized-Zustand eines Workspace wird gegen den Default SEINES EIGENEN Presets berechnet.
  Grund (Nutzer): vereinheitlicht Change-Handling über alle Presets hinweg.
- **REQ-181** (Datenmodell) unverändert in der Kernaussage, aber Disambiguierungssatz ergänzt:
  beschreibt NUR das Datenmodell, autoritative Ablösung regelt REQ-186.
- **REQ-182** (Override bleibt editierbar) korrigiert: der alte Satz "Bestehende
  Berechtigungsprüfungen ... DÜRFEN nicht verändert werden (Regressionsschutz)" widersprach
  der neuen Entscheidung direkt (die Prüfungen SOLLEN ja abgelöst werden) — umformuliert:
  Regressionsschutz bezieht sich auf die für Nutzer sichtbare Bearbeitungsfähigkeit
  (Bedienelemente/Operationen), NICHT auf den Fortbestand der Legacy-Enforcement-Logik selbst.
- **REQ-183** (Reset) unverändert gelassen — keine Kollision mit der neuen Entscheidung.
- **REQ-186** (NEU, Security, Must): Permission-Modell wird alleinige autoritative
  Durchsetzungsinstanz, löst `UserRole`/`ItemPermission`-Hardcoding vollständig ab.
- **REQ-187** (NEU, Non-Functional, Must): sicherer Migrationspfad mit sichtbarem
  Regressionsrisiko ist Pflicht-Akzeptanzkriterium, kein stiller Cutover. HOW (Dual-Write/
  Shadow-Verify/Cutover-Sequenzierung) bewusst NICHT spezifiziert — Aufgabe von
  database-engineer/senior-developer.
- REQ-184/185 (Settings-IA-Split/Governance-Tab-Rebuild) bewusst NICHT angefasst — bleiben
  UI/UX-Scope für ui-ux-designer, keine Notwendigkeit zur Änderung durch diese Revision.

**Why:** Damit database-engineer und api-specialist im nächsten Pipeline-Schritt den
tatsächlich aktuellen (nicht den additiven) Anforderungsstand zugrunde legen und nicht
versehentlich Legacy-Koexistenz statt Ablösung implementieren.

**How to apply:** Bei jeder weiteren Arbeit an REQ-181/182/183/186/187: REQ-186/187 sind die
Quelle für "wird das neue Modell autoritativ" und "wie sicher ist der Rollout abzusichern" —
REQ-181/182/183 bleiben die Quelle für Datenmodell/Override-Editierbarkeit/Reset-Mechanik.
Nicht wieder zusammenführen ohne expliziten Nutzerauftrag.
