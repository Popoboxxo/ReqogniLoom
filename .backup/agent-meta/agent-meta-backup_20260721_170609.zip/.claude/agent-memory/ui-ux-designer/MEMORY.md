# Memory Index

- [WorkflowStatusEditor Integration Pattern](workflow_status_editor_pattern.md) — AdrForm is canonical reference; new entity types need WorkflowArtifactType enum + RESOURCE_PATH entries added
- [State Machine Editor Design (REQ-174)](project_state_machine_editor.md) — React Flow recommended, 3-panel layout, state-type color system, read-only first
- [Workflow/Permissions Global-Default UI (REQ-178..187)](project_workflow_permissions_global_default_ui.md) — System Settings IA split, WorkflowsSection.tsx deletion pending user confirmation
