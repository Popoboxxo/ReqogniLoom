---
name: req-066-service-layer-boundaries
description: REQ-066 (BE-10/A-16) Kontext — kein Repository-Pattern im Code, ORM-in-Service ist dokumentierte Konvention (ADR-AS-01)
metadata:
  type: project
---

REQ-066 basiert auf einer teils falschen Prämisse: Es existiert KEINE Repository-Abstraktion in `backend/` (0 Treffer für "repositor"). ORM direkt in Application-Services ist die dokumentierte Konvention (base.py Docstring, ADR-AS-01, docs/ARCHITECTURE.md: "Application-Layer ist der einzige Ort für Transaktionen"). Einziges Query-Kapselungs-Beispiel: `persistence/managers.py` (ArchitectureElementManager.get_with_level, CTE).

**Why:** DEEP_SYSTEM_ANALYSIS BE-10 spricht von "halbherziger Repository-Abstraktion" — gemeint ist real das Fehlen einer Query-Kapselung, nicht ein verletztes bestehendes Pattern. Der eigentlich harte Verstoß ist A-16: direkte ORM-Zugriffe (inkl. Writes und `unscoped`-Manager) in rest_api ViewSets, v.a. AttributeVisibilityConfigViewSet + CustomFieldDefinitionViewSet (kompletter CRUD ohne Service, views.py ~4277-4763). Latenter Bug: views.py:4290 `from persistence.services import RequirementService` → ImportError (nicht exportiert).

**How to apply:** Bei Architektur-Arbeit an REQ-066: empfohlene Interpretation "Repository = Custom Manager/QuerySet" (Django-idiomatisch, Option B im Konzept vom 2026-07-14), kein hexagonaler Repository-Layer über ~183 ORM-Call-Sites. REQ-066-Text in docs/REQUIREMENTS.md:86 muss ggf. angepasst werden — Entscheid des Users einholen.
