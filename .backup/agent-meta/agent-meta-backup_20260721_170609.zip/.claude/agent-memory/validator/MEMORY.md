# Memory Index

- [Docker dev stash-based regression spot-check](project_docker_dev_stash_regression_check.md) — safe git-stash trick against live bind-mounted dev containers to verify "pre-existing failure" claims
- [REQ-178..187 Global-Default Workflow/Permission model](project_req178_187_permission_workflow_global_default.md) — shadow-mode enforcement seam, still not flipped to authoritative anywhere
