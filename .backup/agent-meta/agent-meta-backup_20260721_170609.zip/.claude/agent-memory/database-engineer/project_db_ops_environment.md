---
name: db-ops-environment
description: How to run migrations and raw SQL against the ReqFlow dev DB (Docker, Windows Git Bash gotchas)
metadata:
  type: project
---

Operational facts for running schema/migration work against the ReqFlow dev stack.

- **Backend code is bind-mounted** via `docker-compose.override.yml` (`./backend -> /app`). Host edits to models are seen live by the `backend` container, so `docker-compose exec -T backend python manage.py makemigrations <app>` picks up host changes without a rebuild.
- **Raw SQL / schema inspection:** `manage.py dbshell` FAILS — the backend image has no `psql` client. Use the postgres container directly: `docker-compose exec -T postgres psql -U reqflow -d reqflow -c "<sql>"`.
- **Windows Git Bash MSYS path conversion** mangles absolute container paths (e.g. `/app/...` becomes `C:/Users/.../app/...`). Prefix commands that pass container-absolute paths with `export MSYS_NO_PATHCONV=1` (or use `//app/...`).
- **Verbose SQL logging:** `manage.py` commands emit DEBUG/INFO SQL noise to stderr. Filter with `| grep -v -E "^(DEBUG|INFO)"` to read real output.

**Why:** These cost real debugging time on REQ-173 (migration for Diagram.workspace_id). **How to apply:** reach for these directly on any future migration/SQL task instead of rediscovering them.
