---
name: syseng2-ruleengine-phase2
description: SysEng 2.0 Phase 2 SE-Auditor RuleEngine scaffold — scope boundaries, TRACE-P7 operational decision, follow-up-agent interface, pre-existing red test
metadata:
  type: project
---

SysEng 2.0 Phase 2 "RuleEngine Core" scaffold built on branch `refactor/syseng-2-0-concept` (not yet committed — git agent commits). Lives in `backend/traceability/audit/` (types/registry/rule_engine + rules/). Only TRACE-P7 implemented as reference; the other 12 rules (TRACE-P1/P1b/P2-P6, ARCH-003, VERIF-P8, CONS-P9/P10) are delegated to 3 follow-up developer agents against this interface.

**Why:** Spec source is `docs/UMSETZUNGSPLAN_SYSENG_2.0.md` §2.2 (Pflichtmatrix) + §4 Phase 2. Preset map is the SSOT for which rules run per tier; Minimal is empty by design ("no SE-Auditor mandate").

**How to apply (for follow-up rule agents / future me):**
- Rules self-register via `@register_rule` + `rule_id` constant from `registry.py`; add `from . import <rule>` to `rules/__init__.py`. Engine is never touched.
- Per-tier severity lives in `Rule.severity_for_tier` (TRACE-P2 = WARNING@standard, BLOCKER@extended). Engine re-stamps findings authoritatively.
- Endpoint-type legality is NOT the engine's job — call `traceability.types.check_se_link_semantics`, never duplicate `SE_LINK_SEMANTICS` (§2.1).
- Baseline scope membership SSOT: `baseline.services.resolve_scope_item_ids` (I extracted it from `preview_scope_items` — DRY). Scope-aware rules set `is_scope_aware=True` and use `context.scope_item_ids`.

**TRACE-P7 operational decision (non-obvious):** literal §2.2 wording ("references same-or-superordinate scope") is vacuous under RLS. I defined it operationally as *baseline self-containment*: flag a trace link with exactly one endpoint (XOR) inside the audited scope's id-set = dangling reference in the snapshot. This satisfies the acceptance test (document-scope leak vs project-scope clean) and honours the superordinate-allowance naturally (wider scope = superset → link fully contained there). Documented in `rules/trace_p7.py` docstring.

**Pre-existing red test (NOT mine):** `traceability/tests/test_services_facade.py::TestFacadeCoverage::test_coverage_via_facade` fails in isolation on this branch (coverage counts 0 instead of 1 for a verifies-link). Unrelated to audit/baseline work. See [[se-kaskade-traceability-register]] for the branch context.
