# Requirements Agent Memory

<!-- Index — one line per memory, max 150 chars each -->

- [REQ-ID Stand](req-id-stand.md) — Hoechste vergebene REQ-ID: REQ-140 (2026-07-15, fabric.js/jsdom peer-dependency)
