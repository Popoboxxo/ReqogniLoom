---
name: project-req-id-ledger
description: Höchster vergebener REQ-ID-Stand und bekannte permanente Lücken in docs/REQUIREMENTS.md
metadata:
  type: project
---

Stand 2026-07-19 (nach Vergabe REQ-188, Erstinitialisierungs-/Bootstrap-Anforderung):
höchster vergebener REQ-ID ist **REQ-188**. Nächste freie ID: **REQ-189**.

REQ-188 (Non-Functional, Should, Proposed) ergänzt REQ-178 (siehe
[[project_workflow_permissions_global_default]]): REQ-178 regelt das Datenmodell des globalen
Workflow-Defaults, REQ-188 regelt den Trigger-Mechanismus der Erstinitialisierung (Admin-Account +
Workflow-Definitionen selbstständig beim ersten App-Start, ohne separaten bootstrap-Service/-Command).

Bekannte permanente Lücken (nie nachbelegen, nie wiederverwenden): **REQ-168**, **REQ-175**.
Diese IDs tauchen in keiner Version von docs/REQUIREMENTS.md auf; vermutlich in einem anderen
Branch/Session vergeben und dort nie gemerged. Nicht nachträglich einfügen ohne expliziten
Auftrag des Nutzers.

**Why:** Mehrere parallele Branches (z.B. `feat/workflow-engine-redesign`, `feat/ux-review-workflow-editor`)
vergeben REQ-IDs unabhängig voneinander; Merge-Reihenfolge erzeugt Lücken. IDs werden nie geändert
oder recycelt (Projektkonvention), auch wenn sie nie im Haupt-Dokument auftauchen.

**How to apply:** Vor Vergabe neuer REQ-IDs immer docs/REQUIREMENTS.md direkt nach dem höchsten
REQ-xxx durchsuchen (nicht nur diese Notiz). Diese Notiz nach jeder Vergabe-Session aktualisieren.
