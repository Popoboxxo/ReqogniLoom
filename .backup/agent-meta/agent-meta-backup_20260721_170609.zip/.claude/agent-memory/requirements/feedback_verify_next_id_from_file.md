---
name: feedback-verify-next-id-from-file
description: Nächste freie REQ-ID immer live aus docs/REQUIREMENTS.md ermitteln, nie aus Memory-Notizen übernehmen
metadata:
  type: feedback
---

Vor Vergabe neuer REQ-IDs MUSS der tatsächliche Höchststand direkt aus docs/REQUIREMENTS.md
gelesen werden (letzte REQ-xxx-Zeile im Dokument) — nicht aus einer alten Memory-Notiz übernehmen.

**Why:** Eine frühere Session-Notiz behauptete "nächste freie ID: REQ-175" (Stand 2026-07-17,
Branch feat/workflow-engine-redesign). Tatsächlich waren zum Zeitpunkt dieser Aufgabe
(2026-07-18) bereits REQ-176 und REQ-177 auf einem anderen Branch (feat/ux-review-workflow-editor)
vergeben und in der Datei eingetragen — die Notiz war veraltet und hätte zu einer ID-Kollision
geführt, wäre sie ungeprüft übernommen worden. Der Auftraggeber wies explizit darauf hin, die
Notiz nicht zu vertrauen und stattdessen die Datei zu prüfen.

**How to apply:** Bei jeder REQ-ID-Vergabe: Grep/Read auf docs/REQUIREMENTS.md für die höchste
REQ-xxx-Nummer, bekannte Lücken beachten (siehe [[project_req_id_ledger]]), erst dann neue IDs
vergeben. Memory-Notizen zum REQ-Stand nur als Kontext, nie als alleinige Quelle.
