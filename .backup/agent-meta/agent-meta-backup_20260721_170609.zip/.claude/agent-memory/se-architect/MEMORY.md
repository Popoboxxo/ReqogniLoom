# Memory Index

- [Workflow Engine Multi-Type Redesign](project_workflow_engine_multitype.md) — REQ-165/166/167: item_type field already exists, gap is provisioning + per-entity presets + mirror map + REST mixin + TestCase status field
