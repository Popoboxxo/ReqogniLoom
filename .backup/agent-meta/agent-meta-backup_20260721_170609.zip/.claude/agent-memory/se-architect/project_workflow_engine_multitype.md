---
name: project-workflow-engine-multitype
description: Workflow engine multi-entity-type redesign (REQ-165/166/167) — key architectural facts about what already exists vs. what is a gap
metadata:
  type: project
---

Universal Configurable Workflow Engine per Entity Type (REQ-165 coverage, REQ-166 per-type presets, REQ-167 approval dialog). Branch `feat/workflow-engine-redesign`.

**Why:** Only Requirement works end-to-end today; Adr/Risk/Issue/TestCase/ChangeRequest/StakeholderNeed are partially wired or not at all.

**How to apply — non-obvious facts (verify before acting, code moves):**
- `WorkflowEngineDefinition` (backend/workflow/models.py) ALREADY has an `item_type` CharField + unique constraint `(tenant, workspace_id, item_type)`. Per-entity-type config is a **provisioning gap, not a schema gap**. No new field needed for scoping.
- `WorkflowFacade` (backend/application/workflow_facade.py) is ALREADY fully generic — takes `item_type` + `workspace_id`. No change needed.
- Adr/Risk/Issue/ChangeRequest services ALREADY call `initialize_workflow_states(item_type=...)` but **silently swallow** the "no definition" error, so no WorkflowItemState is created because only `item_type="Requirement"` is provisioned in `WorkspaceService.create_workspace` (application/workspace_service.py ~line 160).
- `_STATUS_MIRROR_MODELS` (lifecycle_manager.py) only maps Requirement + StakeholderNeed. `_sync_status_mirror` writes `current_state` verbatim into the entity `status` field → **preset state names MUST equal the entity's canonical Status.choices labels**, else the mirror writes invalid values.
- `PRESET_SCHEMAS` (definition_store.py) is entity-agnostic (draft/approved/deprecated) — does NOT match Adr/Risk/Issue label sets. Needs per-entity-type schema variants.
- TestCase (persistence/models.py:891) has NO status field at all.
- All entity ViewSets inherit `BaseEntityViewSet(PresetGateMixin, viewsets.ViewSet)`. The `transitions/` + `workflow-history/` actions exist ONLY on RequirementViewSet → extract a `WorkflowTransitionsMixin`.
- Frontend `WorkflowStatusEditor` + `workflow-transitions.ts` already declare all 6 artifact types + API paths; only RequirementForm consumes it.

Related: [[workflow-checkpointing]]
