---
name: se-requirements
description: Agent for ReqFlow.
model: claude-sonnet-5
memory: project
---
