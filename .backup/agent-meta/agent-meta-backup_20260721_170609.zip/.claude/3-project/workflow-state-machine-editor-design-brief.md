# Design Brief: Visual State Machine Editor (REQ-174)

**Scope:** WorkflowEditorPage — grafischer State-Machine-Editor für alle Entity-Typen in ReqFlow  
**Status:** Design-Spec v1.0  
**Branch:** feat/workflow-engine-redesign  
**Audience:** Senior Developer zur Implementierung  

---

## 1. Library-Empfehlung: @xyflow/react (React Flow v12)

**Empfehlung: @xyflow/react als neue Dependency hinzufügen.**

### Analyse der vorhandenen Dependencies

| Library | Vorhanden | Eignung für State-Machine-Editor |
|---------|-----------|----------------------------------|
| `fabric` v6.4 | Ja | NICHT geeignet: fabric ist für Freihand-Canvas (Zeichnen, Bilder, freie Shapes). Es fehlt: Edge-Routing zwischen Knoten, Handle/Port-System, Auto-Layout, Bezier-Kurven-Management. Alles müsste von Hand gebaut werden — ~2× der Aufwand. |
| `mermaid` v11.4 | Ja | Nur für read-only Export: mermaid rendert `stateDiagram-v2`-Syntax in SVG mit eigenem Styling. Das SVG lässt sich kaum auf das Dark Slate Theme anpassen. Nicht interaktiv. |
| `@xyflow/react` | Nein | Purpose-built für genau diesen Use-Case: Node-basierte Diagramme mit Edges, Handles, Zoom/Pan. TypeScript-first, vollständig anpassbare Node/Edge-Komponenten (React Components), eingebautes Hit-Detection, Auto-Layout via `@dagrejs/dagre`. ~130 KB gzipped. |

### Begründung gegen Fabric

Fabric.js liegt im Bundle für `CanvasEditor` (freeform Diagramm-Zeichnung). Das ist ein anderer Use-Case. Einen Graph-Editor auf Fabric aufzubauen erfordert: eigene Edge-Routing-Mathematik, Bezier-Kurven zwischen Ports, Arrow-Heads, Label-Positionierung, Drag-from-Handle-Gesten — das ist kein "wiederverwendetes Dep", das ist custom Graph-Framework. React Flow erspart ca. 3–5 Entwicklungswochen.

### Mermaid als Fallback nutzen

Mermaid bleibt nützlich für:
- **Diagram-Export**: "Als Mermaid-Diagramm kopieren" button (read-only)
- **Print-View**: Mermaid-Rendering als druckbares SVG

---

## 2. Gesamtlayout: WorkflowEditorPage

### Layout-Struktur (3-Panel)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  WorkflowEditorHeader                                                        │
│  [Workflow Editor]  [Preset: Extended ▾]  [Edit Mode]  [Export ▾]  [?]      │
├──────────────┬──────────────────────────────────────────┬────────────────────┤
│              │                                          │                    │
│  Entity      │   WorkflowCanvas                         │  InspectorPanel    │
│  Selector    │                                          │                    │
│              │   ┌──────────────────────────────────┐   │  [nothing selected]│
│  ● Req       │   │  Canvas Toolbar                  │   │                    │
│  ○ Need      │   │  [+] [-] [Fit] [Grid] [Mermaid ▾]│   │  Klicke einen      │
│  ○ Arch      │   └──────────────────────────────────┘   │  State oder eine   │
│  ○ ADR       │                                          │  Transition        │
│  ○ Risk      │   ┌─[DRAFT]──┐    ┌─[IN_REVIEW]──┐      │  um Details        │
│  ○ TestCase  │   │ initial  │───>│ active       │      │  zu sehen.         │
│  ○ Issue     │   └──────────┘    └──────────────┘      │                    │
│              │        │               │    │            │                    │
│  ──────────  │        ▼               │    ▼            │                    │
│  7 states    │   ┌─[ARCHIVED]──┐     │  ┌─[APPROVED]──┐│                    │
│  3 presets   │   │ terminal    │     │  │ terminal    ││                    │
│              │   └─────────────┘     │  └─────────────┘│                    │
│              │                       ▼                  │                    │
│              │              ┌─[REJECTED]──┐             │                    │
│              │              │ error       │             │                    │
│              │              └─────────────┘             │                    │
│              │                                          │                    │
├──────────────┴──────────────────────────────────────────┴────────────────────┤
│  StatusBar: "Requirement Workflow · 5 states · 7 transitions · Read-only"    │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Panel-Dimensionen

| Panel | Breite | Verhalten |
|-------|--------|-----------|
| EntitySelector (links) | 200 px, fix | Nicht resize-bar; collapsible über Icon-Button |
| WorkflowCanvas (mitte) | flex-grow: 1 | Nimmt restlichen Platz; React Flow Viewport |
| InspectorPanel (rechts) | 280–400 px | Resizable per Drag-Handle (wie RightSidebar); collapsible |

Die drei-Panel-Struktur folgt dem RightSidebar-Pattern: `localStorage`-Persistenz für Breite und Collapsed-State, analog zu `reqflow_inspector_collapsed_${kind}`.

---

## 3. WorkflowEditorHeader

```
┌────────────────────────────────────────────────────────────────────────────┐
│  ○ Workflow Editor                    [Standard ▾]  [Edit Mode ○]  [↑ ▾]  │
└────────────────────────────────────────────────────────────────────────────┘
```

### Elemente (links nach rechts)

- **Breadcrumb/Titel**: `Workflow Editor` — `--font-size-xl`, `fontWeight: 600`
- **Preset-Badge**: Dropdown `Standard | Minimal | Extended` — Pill-Shape mit `--color-badge-info-bg` / `--color-badge-info-text`; read-only info, kein Edit im Header
- **Edit-Mode Toggle**: Toggle-Switch (off = "Read-only", on = "Editing") mit `--color-primary` im An-Zustand; disabled wenn User kein ADMIN-Recht hat
- **Export-Dropdown**: Primär-Button-Style, Optionen: "Copy as Mermaid", "Download PNG", "Download SVG"

---

## 4. EntityTypeSelector (linkes Panel)

### Layout

```
┌────────────────────┐
│  Entity Types      │  ← Section-Header, --font-size-sm, muted
│                    │
│  ● Requirement     │  ← aktiv: --color-primary linker Balken + --color-card-active-bg bg
│    5 states        │
│                    │
│  ○ Stakeholder...  │
│    4 states        │
│                    │
│  ○ Architecture    │
│    6 states        │
│  ○ ADR             │
│    4 states        │
│  ○ Risk            │
│    5 states        │
│  ○ TestCase        │
│    5 states        │
│  ○ Issue           │
│    6 states        │
│                    │
│  ──────────────    │
│  [Extended]        │  ← Preset-Badge, bottom of panel
└────────────────────┘/
```

### EntityTypeItem-Design

**Inactive:**
```
background: transparent
border-left: 3px solid transparent
padding: var(--space-3) var(--space-4)
cursor: pointer
```

**Hover:**
```
background: rgba(99, 102, 241, 0.08)
border-left: 3px solid var(--color-border)
transition: var(--transition-fast)
```

**Active:**
```
background: var(--color-card-active-bg)   /* rgba(99,102,241,0.15) */
border-left: 3px solid var(--color-primary)
```

**Inhalt je Item:**
- Zeile 1: Entity-Name, `--font-size-sm`, `fontWeight: 600`, `--color-text`
- Zeile 2: State-Count, `--font-size-xs`, `--color-text-muted`

**Preset-Badge (Panel-Footer):**
```
background: --color-badge-info-bg
color: --color-badge-info-text
border-radius: --radius-full
padding: 2px 10px
font-size: --font-size-xs
fontWeight: 600
```

---

## 5. WorkflowCanvas (Canvas-Bereich)

### Canvas-Toolbar

Horizontale Leiste, direkt am oberen Canvas-Rand, `--color-surface-raised` Background:

```
[+] [-] [Fit to view]  |  [Grid ☑]  |  [Mermaid ▾]  |  [?]
```

| Button | Icon (lucide-react) | Funktion |
|--------|---------------------|----------|
| Zoom In | `ZoomIn` | React Flow `zoomIn()` |
| Zoom Out | `ZoomOut` | React Flow `zoomOut()` |
| Fit | `Maximize2` | React Flow `fitView()` |
| Grid Toggle | `Grid3x3` | Dotted-Grid-Background ein/aus |
| Mermaid Export | `Code2` | Dropdown: Copy / Download |
| Help | `HelpCircle` | Tooltip-Overlay mit Tastatur-Shortcuts |

### Canvas-Hintergrund

Dotted-Grid Pattern: `--color-border` Punkte (opacity 0.3), 20px spacing.  
Background: `--color-surface` (#0f172a dark / #f8fafc light).

### Empty State

Wenn kein Entity-Typ ausgewählt oder Entity hat keine States:

```
┌─────────────────────────────────┐
│                                 │
│         ⬡                      │
│    No workflow defined          │
│    for this entity type.        │
│                                 │
│    [Initialize Workflow]        │
│                                 │
└─────────────────────────────────┘
```

Icon: `Workflow` aus lucide-react, 48px, `--color-text-muted`.  
Text: `--color-text-muted`, `--font-size-base`.  
Button: Primary-Style, öffnet Initialize-Dialog (nur im Edit-Mode sichtbar).

### Auto-Layout

Initiales Layout via `@dagrejs/dagre`: Top-to-Bottom (`rankdir: 'TB'`), Knoten-Abstand 80px horizontal / 100px vertikal. Dagre ist eine Peer-Dep von React Flow, kein zusätzliches Bundle-Gewicht.

---

## 6. StateNode-Design

### Anatomie eines StateNode

```
┌─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─┐
│  ╔════════════════════════════╗   │
│  ║  [●] DRAFT             [→]║   │
│  ║  initial              3 out║  │
│  ╚════════════════════════════╝   │
└─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─┘
    ^
    Handles (invisible unless hover/edit-mode)
```

### Stil-Spezifikation

**Base (alle States):**
```
background: var(--glass-bg)           /* rgba(30, 41, 59, 0.65) */
border: 1px solid var(--glass-border) /* rgba(255,255,255,0.08) */
border-left: 4px solid <type-color>   /* Typ-spezifische Akzentfarbe */
border-radius: var(--radius-md)       /* 12px */
padding: var(--space-3) var(--space-4)
min-width: 160px
max-width: 220px
backdrop-filter: blur(8px)
box-shadow: var(--shadow-card)
transition: var(--transition-fast)
```

**Header-Zeile (Knoten-Name):**
```
font-family: var(--font-sans)     /* Outfit/Inter */
font-size: var(--font-size-sm)
font-weight: 700
color: var(--color-text)          /* #f8fafc dark / #0f172a light */
letter-spacing: 0.05em
text-transform: uppercase
```

**Sub-Zeile (Typ + Outgoing-Count):**
```
font-size: var(--font-size-xs)
color: var(--color-text-muted)
display: flex, justify-content: space-between
```

**Typ-Icon (links im Header):**  
Kleiner farbiger Kreis (8px) in der Typ-Farbe, kein Lucide-Icon um die Kompaktheit zu wahren.

**Transition-Count (rechts):**  
Kleiner Pfeil-Icon `ArrowRight` aus lucide-react, 12px, Muted Color + Zahl.

### Farbkonzept nach State-Typ

| Typ | Linker Balken | Kreis-Icon | Glow bei Hover |
|-----|---------------|------------|----------------|
| `initial` | `#6366f1` (--color-primary / Indigo 500) | Indigo | `rgba(99,102,241,0.25)` |
| `active` | `#10b981` (--color-success / Emerald 500) | Emerald | `rgba(16,185,129,0.2)` |
| `terminal` | `#94a3b8` (--color-text-muted / Slate 400) | Gray | keine |
| `error` | `#ef4444` (--color-danger / Red 500) | Red | `rgba(239,68,68,0.2)` |

**Rationale:**
- Indigo für `initial`: passt zum app-weit dominanten Primary-Token, signalisiert "hier startet der Flow"
- Emerald für `active`: positiv, in Bewegung — korrespondiert mit `--color-success` (bereits für Approved-Badges genutzt)
- Slate für `terminal`: neutral, final — keine Energie mehr im Lifecycle
- Red für `error`/`rejected`: passt zu `--color-danger`, sofort erkennbar

### Hover-State

```
box-shadow: 0 0 0 1px var(--color-primary), var(--shadow-card), <type-glow>
border-color: var(--color-border-hover)
transform: translateY(-1px)
```

Handles (Verbindungspunkte) erscheinen: 4 kleine Kreise (6px) an Top/Right/Bottom/Left, `--color-primary` fill, nur sichtbar on hover (read-only: transparent, edit-mode: sichtbar).

### Selected-State

```
box-shadow: 0 0 0 2px var(--color-primary), var(--shadow-glow)
border-color: var(--color-primary)
```

### Sonderfälle

**Initial State** (genau 1 per Machine): Zusätzlicher kleiner "Play"-Indikator oben-links (`ChevronRight` Icon in Indigo, 10px).

**Terminal State**: Doppelter Rand-Effekt via `outline: 2px solid rgba(148,163,184,0.3)` mit `outline-offset: 3px`.

**Error State**: Subtile rote `box-shadow: 0 0 8px rgba(239,68,68,0.15)` im Ruhezustand.

---

## 7. TransitionEdge-Design

### Pfeil-Stil

```
stroke: var(--color-border-hover)  /* #475569 — Slate 600 */
stroke-width: 1.5
edge-type: bezier                  /* React Flow default */
arrow-type: arrowclosed            /* gefüllte Pfeilspitze */
```

### Label-Design

Jeder Edge hat ein Label (Transition-Name) als floating Pill:

```
background: var(--color-surface-raised)   /* #1e293b */
border: 1px solid var(--color-border)
border-radius: var(--radius-full)
padding: 2px 8px
font-size: var(--font-size-xs)
color: var(--color-text-muted)
font-weight: 500
max-width: 140px
white-space: nowrap
overflow: hidden
text-overflow: ellipsis
```

**Lock-Icon** bei `change_reason_required: true`:
Mini-Icon `Lock` aus lucide-react (10px) links vom Label-Text in `--color-warning` (#f59e0b).

**Gate-Badge** bei definiertem Guard/Condition:
Kleines `[cond]` in `--color-badge-info-text` rechts vom Label.

**Hover-State Edge:**
```
stroke: var(--color-primary)
stroke-width: 2.5
label: color: --color-text (statt muted), background: leicht aufgehellt
```

**Selected-State Edge:**
```
stroke: var(--color-primary)
stroke-width: 3
label: box-shadow: 0 0 0 2px rgba(99,102,241,0.3)
```

### Self-Loops (State → gleicher State)

Bei `from === to`: React Flow `type: 'selfconnecting'`, der Loop wird als kleiner Bogen rechts am Knoten gerendert.

---

## 8. InspectorPanel (rechtes Panel)

Collapsible (analog RightSidebar), resizable zwischen 280–400px, `localStorage`-Persistenz unter Key `reqflow_workflow_inspector_width`.

### Zustand: nichts ausgewählt

```
┌────────────────────────────────┐
│  Inspector            [«] [📌] │
│  ──────────────────────────── │
│                                │
│   [Workflow Icon 32px]         │
│                                │
│   Select a state or            │
│   transition to inspect it.    │
│                                │
└────────────────────────────────┘
```

### Zustand: State ausgewählt

```
┌────────────────────────────────┐
│  Inspector            [«] [📌] │
│  ──────────────────────────── │
│  [●] DRAFT          [initial]  │
│                                │
│  Description                   │
│  ──────────                    │
│  The artifact has been         │
│  created but not yet           │
│  submitted for review.         │
│                                │
│  Outgoing Transitions  (3)     │
│  ──────────────────────        │
│  → IN_REVIEW          [🔒]    │
│  → ARCHIVED                    │
│  → DELETED                     │
│                                │
│  Incoming Transitions  (0)     │
│  ──────────────────────        │
│  (initial state — no           │
│   incoming transitions)        │
│                                │
│  ─── Edit Mode ────────────── │
│  [Edit State]  [Delete State]  │ ← nur sichtbar wenn Edit-Mode an
└────────────────────────────────┘
```

**State-Header:** Name bold uppercase, Typ-Badge (Pill, colored per Typ-Farbkonzept), Typ-Icon-Dot.

**Description:** `--font-size-sm`, `--color-text-muted`, italic, max 3 Zeilen dann `expand`-Link.

**Transition-Listen:** Klickbar — Klick auf Transition selektiert den entsprechenden Edge im Canvas. Arrow-Icon + Transition-Name. `--color-warning` Lock-Icon wo relevant.

### Zustand: Transition ausgewählt

```
┌────────────────────────────────┐
│  Inspector            [«] [📌] │
│  ──────────────────────────── │
│  [→] submit_for_review         │
│                                │
│  From                          │
│  DRAFT  →  IN_REVIEW          │
│                                │
│  Rules                         │
│  ──────                        │
│  Required Role    author       │
│  Change Reason    Required [🔒]│
│  Guard Condition  —            │
│                                │
│  ─── Edit Mode ────────────── │
│  [Edit Transition]  [Delete]   │
└────────────────────────────────┘
```

---

## 9. Interaktionsmuster

### Read-Only Mode

| Trigger | Verhalten |
|---------|-----------|
| Click StateNode | Node selected, InspectorPanel zeigt State-Details |
| Click TransitionEdge | Edge selected, InspectorPanel zeigt Transition-Details |
| Hover StateNode | Node lifts, Handles visible (transparent/dim), Tooltip: "DRAFT · initial · 3 outgoing" |
| Hover TransitionEdge | Edge highlighted (Indigo), Label full-color |
| Click Entity in Selector | Canvas neu geladen mit Workflow dieses Entity-Typs, selection resettet |
| Scroll/Pinch | Zoom (React Flow native) |
| Drag Canvas | Pan (React Flow native) |
| Tab | Nächster Node fokussiert (keyboard nav) |
| Enter / Space | Fokussierten Node selektieren |
| Escape | Selektion aufheben |
| Ctrl+Shift+F / Cmd+Shift+F | Fit-to-View |

### Edit Mode (Phase 2 — optionale Erweiterung)

| Trigger | Verhalten |
|---------|-----------|
| Drag von Handle (Node-Rand) | Neue Transition ziehen; Dropp auf Node → Transition-Dialog |
| Dropp auf leerem Canvas | "Neuen State hier erstellen + Transition dazu?" Dialog |
| Double-Click Node | State-Name inline editieren |
| Double-Click Canvas (leer) | "Neuen State hinzufügen" Dialog an Cursor-Position |
| Delete / Backspace | Ausgewählten State oder Transition löschen (Confirmation required) |
| Drag Node | State verschieben (Position wird persistiert) |

### Tooltip-Inhalt (Hover auf State)

```
State: DRAFT
Type: initial
Outgoing: 3 transitions
Incoming: 0 transitions
[Click to inspect]
```

Tooltip erscheint nach 600ms Delay, 12px Abstand vom Node, `--color-surface-raised` bg, `--color-border` border, `--font-size-xs`.

---

## 10. Dialogboxen (Edit Mode)

### "Add State" Dialog

Modal, `--color-surface-raised` bg, `--shadow-card`, 400px Breite:

```
┌─────────────────────────────────┐
│  Add State               [×]    │
│  ─────────────────────────────  │
│  Name *                         │
│  [IN_PROGRESS             ]     │
│                                 │
│  Type *                         │
│  ○ initial  ● active            │
│  ○ terminal ○ error             │
│                                 │
│  Description                    │
│  [                          ]   │
│  [                          ]   │
│                                 │
│  [Cancel]         [Add State]   │
└─────────────────────────────────┘
```

### "Add Transition" Dialog

```
┌─────────────────────────────────┐
│  Add Transition          [×]    │
│  ─────────────────────────────  │
│  From state: DRAFT (prefilled)  │
│                                 │
│  To State *                     │
│  [IN_REVIEW              ▾]     │
│                                 │
│  Name *                         │
│  [submit_for_review       ]     │
│                                 │
│  Required Role                  │
│  [author                  ]     │
│                                 │
│  ☑ Require change reason        │
│                                 │
│  [Cancel]     [Add Transition]  │
└─────────────────────────────────┘
```

---

## 11. Farbkonzept — Zusammenfassung

### State-Typ-Farben (Canonical)

| Typ | Farbe | Token / Hex | Verwendung |
|-----|-------|-------------|------------|
| `initial` | Indigo | `--color-primary` / #6366f1 | Linker Balken, Dot, Glow |
| `active` | Emerald | `--color-success` / #10b981 | Linker Balken, Dot, Glow |
| `terminal` | Slate | `--color-text-muted` / #94a3b8 | Linker Balken, Dot (no glow) |
| `error` | Red | `--color-danger` / #ef4444 | Linker Balken, Dot, subtle glow |

### Edge-Farben

| Zustand | Farbe | Hex |
|---------|-------|-----|
| Default | Slate 600 | `--color-border-hover` / #475569 |
| Hover | Indigo | `--color-primary` / #6366f1 |
| Selected | Indigo | `--color-primary` / #6366f1 |
| Self-loop | Slate 500 | `--color-text-muted` / #94a3b8 |

### Canvas-Hintergrund

| Element | Farbe |
|---------|-------|
| Canvas bg | `--color-surface` (#0f172a dark / #f8fafc light) |
| Grid dots | `--color-border` opacity 0.25 |
| Panel bg | `--color-surface-raised` (#1e293b dark / #ffffff light) |

---

## 12. Accessibility

| Anforderung | Umsetzung |
|-------------|-----------|
| Keyboard navigation | Tab-Reihenfolge durch alle Nodes, Enter/Space für Selektion, Escape für Dismiss |
| Screen reader | StateNode hat `role="button"`, `aria-label="State: DRAFT, type initial, 3 outgoing transitions"` |
| TransitionEdge | `role="button"`, `aria-label="Transition: submit_for_review from DRAFT to IN_REVIEW"` |
| Focus visible | `outline: 2px solid var(--color-primary)`, `outline-offset: 2px` auf allen interaktiven Elementen |
| Color not sole indicator | State-Typ durch Farbe UND Icon-Shape UND Text-Badge kommuniziert |
| Zoom | Keine feste Pixelgröße für Text innerhalb Canvas; SVG-basierte Skalierung |
| Live region | InspectorPanel-Updates via `aria-live="polite"` |
| Contrast | Alle Text-Farb-Kombinationen AA-konform (getestet gegen dark + light token sets) |

---

## 13. Empfehlung: Read-Only first vs. direkt editierbar

**Empfehlung: Read-Only first, Edit-Mode als Phase 2.**

### Begründung

**Phase 1 (Read-Only)** liefert sofort Wert:
- Entwickler und PMs verstehen welche States/Transitions existieren — heute ein blinder Fleck (rohe UUIDs in Admin-Form)
- Onboarding neuer Teammitglieder auf Workflows massiv vereinfacht
- Design-Verifikation: Team kann prüfen ob Preset-States korrekt konfiguriert sind
- Implementierungsaufwand: ~70% des Gesamtaufwands (Nodes, Edges, Styling, Layout, Inspector, API-Integration)

**Phase 2 (Edit Mode)** erhöht Komplexität erheblich:
- Neue API-Endpunkte nötig (POST state, POST transition, DELETE state, DELETE transition, PUT state)
- Undo/Redo-Stack (React Flow History Plugin)
- Validierung (kein Duplicate State Name, kein orphaned State ohne Transitions, exakt 1 initial State)
- Optimistic Updates + Error Rollback
- Role-based Gating (nicht jeder darf Workflows editieren)
- Auto-Save vs. Save-Button — beide Patterns haben Tradeoffs

**Zeitliche Entkopplung zahlt sich aus:** Read-Only in Sprint N, Edit in Sprint N+2 nach User-Feedback.

---

## 14. Komponenten-Struktur

```
WorkflowEditorPage
├── WorkflowEditorHeader
│   ├── PageTitle ("Workflow Editor")
│   ├── PresetBadge (dropdown: Minimal / Standard / Extended)
│   ├── EditModeToggle (disabled wenn kein ADMIN-Recht)
│   └── ExportDropdown (Copy Mermaid / Download PNG / Download SVG)
│
├── WorkflowEditorLayout  (flex row, height: calc(100vh - header))
│   │
│   ├── EntityTypeSelector  (left panel, 200px)
│   │   ├── SectionLabel ("Entity Types")
│   │   ├── EntityTypeItem × 7  (Requirement | Need | Arch | ADR | Risk | TestCase | Issue)
│   │   │   └── [name, state-count]
│   │   └── PresetBadge (panel footer)
│   │
│   ├── WorkflowCanvas  (center, flex-grow)
│   │   ├── CanvasToolbar
│   │   │   ├── ZoomInButton
│   │   │   ├── ZoomOutButton
│   │   │   ├── FitViewButton
│   │   │   ├── GridToggle
│   │   │   ├── MermaidExportDropdown
│   │   │   └── HelpButton
│   │   ├── ReactFlowProvider
│   │   │   ├── ReactFlow (nodes, edges, onNodeClick, onEdgeClick)
│   │   │   │   ├── StateNode (custom node component)
│   │   │   │   │   ├── NodeHeader (type-dot, name, outgoing-count)
│   │   │   │   │   ├── NodeSubline (type-label)
│   │   │   │   │   └── Handles (top, right, bottom, left)
│   │   │   │   ├── TransitionEdge (custom edge component)
│   │   │   │   │   ├── BezierPath
│   │   │   │   │   ├── EdgeLabel (transition-name, lock-icon, gate-badge)
│   │   │   │   │   └── ArrowMarker
│   │   │   │   ├── Background (dotted grid)
│   │   │   │   └── Controls (react-flow minimap optional)
│   │   │   └── EmptyStateOverlay (kein Entity ausgewählt / keine States)
│   │   └── WorkflowLoadingOverlay (während API-Fetch)
│   │
│   └── InspectorPanel  (right panel, 280-400px, collapsible)
│       ├── InspectorHeader (title, pin, collapse)
│       ├── ResizeHandle (left edge)
│       ├── EmptyInspector (nichts selektiert)
│       ├── StateInspector (wenn StateNode selektiert)
│       │   ├── StateHeader (type-dot, name, type-badge)
│       │   ├── StateDescription (expandable)
│       │   ├── OutgoingTransitionList
│       │   ├── IncomingTransitionList
│       │   └── EditActions (nur Edit-Mode: Edit, Delete)
│       └── TransitionInspector (wenn TransitionEdge selektiert)
│           ├── TransitionHeader (arrow-icon, name)
│           ├── TransitionFlow (from → to)
│           ├── TransitionRules (role, change_reason, guard)
│           └── EditActions (nur Edit-Mode: Edit, Delete)
│
└── StatusBar
    └── StatusText ("Requirement Workflow · 5 states · 7 transitions · Read-only")
```

---

## 15. Neue Route

```
/settings/workflows          → WorkflowEditorPage (read-only)
/settings/workflows/:entityType   → WorkflowEditorPage mit vorausgewähltem Entity-Typ
```

Die Seite wird als neuer Entry-Point in den WorkspaceSettings-Bereich oder als eigenständige Route unter `/workflows` eingehängt. Empfehlung: eigenständige Route mit Sidebar-Nav-Eintrag ("Workflows"), da die Visualisierung kein Settings-Formular ist sondern ein eigenständiges Tool.

---

## Delivery-Reihenfolge für den Developer

1. **Route + Page-Shell**: `WorkflowEditorPage` mit leerem Canvas, EntitySelector Routing
2. **API-Integration**: Workflow-States und Transitions per Entity-Typ laden (GET-Endpoints)
3. **Read-only Canvas**: React Flow + StateNode + TransitionEdge + Auto-Layout (dagre)
4. **InspectorPanel**: State-Inspector + Transition-Inspector
5. **Canvas-Toolbar**: Zoom, Fit, Mermaid-Export
6. **EntityTypeSelector**: alle 7 Entity-Typen, Preset-Badge
7. **Header + StatusBar**: EditModeToggle (disabled in Phase 1), Export-Dropdown
8. **[Phase 2] Edit-Mode**: Add/Edit/Delete Dialoge, API-Mutations, Undo/Redo

---

*Design Brief v1.0 — UI/UX Designer Agent — ReqFlow feat/workflow-engine-redesign*
