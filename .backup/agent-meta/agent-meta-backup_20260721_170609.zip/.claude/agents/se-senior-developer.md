---
name: se-senior-developer
description: Agent for ReqFlow.
model: claude-opus-4-8
memory: project
---
