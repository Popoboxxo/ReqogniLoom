# Memory Index

- [DB Ops Environment](project_db_ops_environment.md) — run SQL via postgres container (not dbshell), MSYS path + bind-mount gotchas
- [Workspace Scoping Pattern](project_workspace_scoping_pattern.md) — artifact tables scope via decoupled workspace_id UUIDField, not a real FK
- [Global-Default/Override Model](project_global_default_override_model.md) — REQ-178..183 materialized-copy global default + why permissions aren't symmetric to workflows
