# Memory Index

- [REQ-165/166 Workflow Engine PR split](project_req165_166_workflow_engine_pr_split.md) — 3-PR sequence; PR1 backend done, PR2 REST, PR3 frontend; scope boundaries + key invariants
- [REQ-169/170/171 Workflow bugfixes](project_workflow_engine_req169_171_bugfixes.md) — effective change_reason, Requirement backfill, Architecture wired in (no status mirror invariant)
- [Workflow Editor REQ-176/177](project_workflow_editor_req176_177.md) — visual editor read-only + edit mode; states-as-strings, Extended-only editing, id conventions, client-side positions
- [Global-Default UI REQ-178..187](project_workflow_permissions_global_default_ui.md) — scope-parameterized WorkflowEditorPage, Settings IA-split, System Settings, enforcement flip guard, pre-existing test flakes
- [Global-Default Backend REQ-178..187](project_workflow_permissions_global_default_backend.md) — REST-only shadow seam, single inheritance seam, flip guard, pre-existing red-test baseline
- [SysEng 2.0 Architecture Role Derivation](project_syseng2_architecture_role_derivation.md) — role derived from tree position (not stored); element_type kept as free-text non-authority; new I5 single-root invariant (all tiers)
- [SysEng 2.0 RuleEngine Phase 2](project_syseng2_ruleengine_phase2.md) — SE-Auditor scaffold in traceability/audit/; TRACE-P7 self-containment decision; rule-agent interface; preset SSOT; pre-existing coverage red test
- [SysEng 2.0 Auditor UI Phase 3](project_syseng2_auditor_ui_phase3.md) — AuditService facade + Adopt/Modify remediation pattern (Layer1 analysis / Layer2 execution split); REST audit endpoints + signatures
- [SysEng 2.0 N1 architecture.decompose](project_syseng2_n1_architecture_decompose.md) — Phase 4a Draft-Staging copilot; frontend-state draft, post-commit-in-tx auditor check, explicit derives-from, preset gate
