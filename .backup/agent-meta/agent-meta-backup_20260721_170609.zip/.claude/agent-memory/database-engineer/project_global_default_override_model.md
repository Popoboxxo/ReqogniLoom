---
name: global-default-override-model
description: REQ-178..183 global-default/override/reset schema — materialized-copy pattern + permissions asymmetry
metadata:
  type: project
---

REQ-178..183 + REQ-186/187 (branch feat/ux-review-workflow-editor, 2026-07-18) introduce a tenant-wide global-default → workspace-override → reset-to-default model for Workflows AND Permissions. **Revised 2026-07-18 (step-2 pass): two original assumptions were OVERRULED by the user — see below.**

**Chosen inheritance form: materialized copy, not by-reference fallthrough.** Each workspace keeps its own definition row (preserves the existing per-workspace `WorkflowEngineDefinition` row + the `WorkflowItemState.definition` PROTECT FK → zero regression). A separate tenant-scoped `GlobalWorkflowDefinition` (table `we_global_definition`) is the source-of-truth template. Workspace rows link back via additive `source_global` (FK, SET_NULL) + `is_customized` bool. **Why materialized over by-reference:** by-reference (on-default workspaces have no own row) would orphan item-state FKs on override — too invasive.

**REVISED — per-preset global defaults (REQ-178 revised).** `GlobalWorkflowDefinition` is unique `(tenant, item_type, PRESET)`, constraint `uq_we_global_def_tenant_type_preset` — NOT one shared default per `(tenant, item_type)`. Each Rigor-Preset (minimal/standard/extended) gets its own global row; a workspace's on-default/customized state is computed against ITS OWN preset's global, never a cross-preset modal. Backfill (0009) groups by `(tenant, item_type, preset)`, modal-seeds within each group. This resolved the earlier Requirement-tier caveat.

**on-default vs customized signal = the `is_customized` boolean** (kept off the hot read path; backfill computes it by canonical-JSON comparison against the global). Reset = copy global json back + clear flag.

**Permissions are NOT structurally symmetric to workflows** — key design constraint. Workflows had a per-workspace `workflow_json` blob; permissions had only per-user `UserRole`/`ItemPermission` rows + a role→capability matrix hardcoded in CODE (COMP-AT-002), no per-workspace definition blob. So a NEW blob pair was introduced: `GlobalPermissionDefinition` + `WorkspacePermissionDefinition` (auth_tenancy) holding the matrix as `permission_json`. auth_tenancy scopes via a real `Workspace` FK, unlike [[workspace-scoping-pattern]]'s decoupled UUIDField.

**REVISED — permissions are REAL enforcement replacement, not additive (REQ-186/187, security-sensitive).** The user ("UserRole und ItemPermission ist mir ein Dorn im Auge") decided the new blob pair MUST become the sole authoritative access-control mechanism, fully replacing the hardcoded UserRole/ItemPermission enforcement — not decorating it. App-wide blast radius. Safe-rollout schema added: `GlobalPermissionDefinition.enforcement_mode` (per-tenant, `shadow`|`authoritative`, default `shadow` = legacy still decides, new observed) + append-only `PermissionDecisionMismatch` table (`at_permission_decision_mismatch`) logging legacy-vs-new decision disagreements during shadow phase. Empty/triaged log = REQ-187 cutover evidence. Dual-write needs no new schema (both stores coexist). Legacy-check removal = SEPARATE later contract migration (not written yet), senior-developer scope.

Migrations are Expand-only (additive tables + nullable/defaulted cols), fully reversible; NOT yet applied (HITL gate). `makemigrations --check` clean after revision. See [[db-ops-environment]].
