# Memory Index

- [Arch-Analyse 2026-07](project-arch-analysis-2026-07.md) — Outbox-Poller unverdrahtet, CACHES fehlt, List-Materialisierung systemisch; Fallen für künftige Reviews
