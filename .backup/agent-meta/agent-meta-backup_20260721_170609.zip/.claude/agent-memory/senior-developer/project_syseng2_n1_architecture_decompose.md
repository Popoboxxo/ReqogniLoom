---
name: syseng2-n1-architecture-decompose
description: SysEng 2.0 Phase 4a N1 (architecture.decompose) — Draft-Staging copilot; frontend-state draft, post-commit-in-transaction auditor check, explicit derives-from
metadata:
  type: project
---

SysEng 2.0 Phase 4a "KI-Copilot N1" (`architecture.decompose`) built on branch
`refactor/syseng-2-0-concept` (not committed — git agent commits). Spec:
`docs/UMSETZUNGSPLAN_SYSENG_2.0.md` §3.1 + §4 Phase 4a. Builds on the RuleEngine
(see [[syseng2-ruleengine-phase2]]) and AuditService (see
[[syseng2-auditor-ui-phase3]]). The copilot decomposes a Subsystem into child
elements + one derived Requirement each, wiring all internal trace links.

**Core facade:** `application/architecture_decompose_service.py`
(`ArchitectureDecomposeService`, COMP-AS-N1, ADR-01 single entry point). Two
phases: `generate_draft(ctx, element_id, breadth, depth)` → non-persistent
`DecompositionDraft`; `commit_draft(ctx, draft)` → `CommitResult`. N3/N5/N8
should reuse this Draft-Staging shape.

**Four load-bearing decisions (how to apply / extend):**
- **Draft = response/frontend state, NO server persistence, no migration.**
  generate returns the draft; the client echoes it back to commit. commit
  re-validates every endpoint through the validated domain services + re-audits,
  so a tampered draft can't bypass invariants.
- **RuleEngine check = post-commit-IN-transaction, rollback on BLOCKER.** commit
  persists inside `TransactionContextManager()`, then runs `RuleEngine().run(...)`
  forced to `tier="extended"` (so ARCH-003/TRACE-P5, which are extended-only in
  `RULE_PRESET_MAP`, always run regardless of the workspace tier), keeps only
  BLOCKER findings for `{ARCH-003, TRACE-P4, TRACE-P5}` that intersect newly
  created ids, and raises `DecompositionAuditError` (→ rollback, → HTTP 422 with
  `.findings`). One mechanism satisfies both "transactional" and "output passes
  the auditor". No in-memory graph simulation (the engine reads ORM rows).
- **N1 explicitly emits the `derives-from` link** — the raw
  `RequirementService.decompose()` emits only `decomposes` + `allocated-to` and
  would FAIL TRACE-P5. Per node N1 creates 3 links: allocated-to (child req →
  child element), decomposes (parent req → child req), derives-from (child req →
  parent req). This is the correctness core.
- **Preset gate in the service** (`_assert_preset_allows` via
  `AuditService.resolve_tier`): `minimal` → `DecompositionNotAvailableError`
  (subclasses PermissionDeniedError → REST 403, MCP FEATURE_NOT_ENABLED). Both
  phases gate, covering REST + MCP.

**Precondition:** the selected element MUST already have an `allocated-to` anchor
Requirement (first by id) — without a parent to derive from, ARCH-003 can never
be satisfied. generate raises ValidationError otherwise.

**Non-obvious id-space gotcha:** SE-Auditor findings mix id spaces —
TRACE-P4 names ArchitectureElement PKs, ARCH-003 mixes an element PK with a
Requirement *artifact* id, TRACE-P5 uses Requirement artifact ids. commit
registers BOTH the PK and the artifact id of every created element/requirement
in the `new_artifact_ids` filter set so no finding slips the intersection.

**Surface added (all additive):**
- MCP: `architecture.decompose` (generate, NOT a write tool) +
  `architecture.decompose_commit` (write) on `ArchitectureToolGroup`
  (`mcp_server/tools/architecture.py`); commit added to `_WRITE_TOOL_PREFIXES`.
- REST: `rest_api/architecture_decompose_views.py`, two workspace-scoped POSTs
  (`.../architecture/decompose/` + `.../decompose/commit/`), wired in urls.py.
- LLM: mock provider purpose `arch_decompose_tree` (deterministic nested tree
  from `breadth`/`depth`/`element_title` context) in `llm_adapter/providers.py`.
- Frontend: `api/architectureDecompose.ts` + standalone
  `components/ArchitectureDecompose/ArchitectureDecomposePanel.tsx` (generate →
  diff-style review → commit; data-testid on all interactives; `archDecompose.*`
  i18n de/en). NOT yet routed into a page — wiring into the Architecture editor
  is a follow-up.

Tests: `application/tests/test_architecture_decompose.py` (9),
`mcp_server/tests/test_architecture_decompose_tool.py` (4),
`src/test/ArchitectureDecomposePanel.test.tsx` (4). Pre-existing red baseline
still applies (see [[syseng2-ruleengine-phase2]]).
