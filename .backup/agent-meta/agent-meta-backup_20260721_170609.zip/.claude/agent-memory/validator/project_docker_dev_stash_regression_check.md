---
name: project_docker_dev_stash_regression_check
description: How to safely spot-check pre-existing-vs-regression test failures in ReqFlow via git stash against the running dev docker stack
metadata:
  type: project
---

ReqFlow's dev docker stack (`docker-compose.yml` + `docker-compose.override.yml`)
bind-mounts `./backend:/app` and the frontend source live into the running
`ai-native-reqflow-poc-backend-1` / `-frontend-1` containers (hot-reload dev
setup). This means `git stash push -u` / `git stash pop` on the host is
reflected immediately inside the containers — no rebuild needed.

**Why this matters for validation:** it makes it safe and cheap to verify an
implementer's "this failure is pre-existing, not a regression" claim by:
1. Running the specific failing test(s) with the feature branch's changes in place.
2. `git stash push -u` (stashes tracked + untracked changes, including new
   migration files).
3. Re-running the exact same test(s) against the now-restored HEAD state.
4. `git stash pop` and verify `git status` is byte-identical to before the stash
   (diff the porcelain output) — confirms a clean, lossless round-trip.

**How to apply:** Even if new DB migrations were already applied to the
persistent dev Postgres DB before the stash, this is still safe: pytest-django
(no `--reuse-db` configured in `backend/pyproject.toml`) creates and tears down
its own separate test database each run, built fresh from whatever migration
files are present on disk at run time — it never touches the already-migrated
dev DB. So stashing migration files only affects the test DB schema for that
run, not the persistent dev DB. Confirmed working 2026-07-18 during REQ-178..187
validation (see [[project_req178_187_permission_workflow_global_default]]):
reproduced identical failure sets (2 ReqIF reimport idempotency failures, 1 RLS
raw-query test failure, 3 mcp_server e2e errors) both with and without the
feature's changes stashed, confirming those failures were genuinely
pre-existing and unrelated to the change under review.
