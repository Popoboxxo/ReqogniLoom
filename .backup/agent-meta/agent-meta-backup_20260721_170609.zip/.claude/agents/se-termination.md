---
name: se-termination
description: Agent for ReqFlow.
model: claude-haiku-4-5-20251001
---
