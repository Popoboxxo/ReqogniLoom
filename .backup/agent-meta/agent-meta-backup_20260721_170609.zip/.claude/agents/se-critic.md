---
name: se-critic
description: Agent for ReqFlow.
model: claude-opus-4-8
---
