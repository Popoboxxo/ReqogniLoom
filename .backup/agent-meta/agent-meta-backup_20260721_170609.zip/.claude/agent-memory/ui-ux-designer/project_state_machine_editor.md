---
name: state-machine-editor-design
description: Design Brief für WorkflowEditorPage (REQ-174) — React Flow empfohlen, 3-Panel-Layout, State-Typ-Farbkonzept, Read-only first
metadata:
  type: project
---

WorkflowEditorPage (REQ-174) Design Brief liegt in `.claude/3-project/workflow-state-machine-editor-design-brief.md`.

Library-Entscheidung: @xyflow/react (React Flow v12) als neue Dependency — fabric.js nicht geeignet (freeform canvas, kein Graph-Routing), mermaid nur für Export-Fallback.

Farbkonzept State-Typen: initial=Indigo(--color-primary), active=Emerald(--color-success), terminal=Slate(--color-text-muted), error=Red(--color-danger).

Layout: 3-Panel (EntitySelector 200px fix | Canvas flex-grow | InspectorPanel 280-400px collapsible+resizable). Neue Route /settings/workflows oder /workflows.

**Why:** Phase-1=read-only reicht für sofortigen Wert (States/Transitions sichtbar machen). Phase-2=Edit-Mode erfordert neue API-Endpunkte + Undo/Redo + Role-Gating.

**How to apply:** Wenn Implementierungsfragen zu WorkflowEditorPage kommen, Design Brief referenzieren. Farb-Tokens und Komponenten-Hierarchie sind vollständig spezifiziert.
