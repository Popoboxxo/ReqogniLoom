---
name: se-architect
description: Agent for ReqFlow.
model: claude-opus-4-8
memory: project
---
