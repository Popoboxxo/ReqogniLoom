---
name: req-id-stand
description: Hoechste vergebene REQ-ID, damit der naechste Batch korrekt weiterzaehlt
metadata:
  type: project
---

Hoechste vergebene REQ-ID: **REQ-140**

Zuletzt vergeben am 2026-07-15: REQ-140 (fabric.js/jsdom peer-dependency-Kompatibilitaet, Non-Functional).
Davor: REQ-139 (Automatisierter CSRF-Regressionstest), REQ-138 (CSRF Trusted Origins), REQ-137 (Preferences GET 200 statt 404), REQ-126 bis REQ-136 (Hermes Campaign).

**Why:** REQ-IDs duerfen nie wiederverwendet oder uebersprungen werden. Dieses Memory verhindert Luecken bei naechsten Batches.

**How to apply:** Naechste REQ-ID ist REQ-141. Vor jeder Vergabe dieses Memory pruefen und danach aktualisieren.
