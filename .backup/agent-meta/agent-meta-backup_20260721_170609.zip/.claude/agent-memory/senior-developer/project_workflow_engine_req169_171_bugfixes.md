---
name: workflow-engine-req169-171-bugfixes
description: REQ-169/170/171 workflow-engine bug fixes on feat/workflow-engine-redesign; the non-obvious Architecture "no status mirror" invariant
metadata:
  type: project
---

Three workflow-engine bugs fixed on branch `feat/workflow-engine-redesign` (follow-up to the [[req165-166-workflow-engine-pr-split]] work), committed separately:

- **REQ-169** — transitions GET now reports the EFFECTIVE `requires_change_reason` (`per_transition_flag OR PresetPolicyService.is_change_reason_required(ws)`) in `rest_api/mixins/workflow_transitions.py`. The facade's global gate blocks empty-reason transitions under Extended rigor regardless of the per-transition flag; the UI needs the effective value to show its reason textarea. `_check_change_reason` in `workflow_facade.py` was intentionally left in place (facade-layer removal is a later Phase-2/Batch-A concern).
- **REQ-170** — migration `workflow/0006` backfills the `Requirement` WorkflowEngineDefinition for pre-existing workspaces (migration 0004 had skipped it). Requirement uses the workspace's tier-dependent preset (minimal/standard/extended), resolved from `WorkspacePresetConfig.active_tier`.
- **REQ-171** — ArchitectureElement wired into the workflow engine.

**Non-obvious invariant (REQ-171):** ArchitectureElement has a workflow but **NO denormalized `status` column** and is **not** in `_STATUS_MIRROR_MODELS` (`workflow/lifecycle_manager.py`). Its workflow state lives ONLY in `WorkflowItemState`; the mirror write is a deliberate silent no-op.

**Why:** adding a status column would need a persistence schema migration + item-state backfill for an entity that never had one; the workflow endpoints work without it because state is read from `WorkflowItemState` (lazily initialised to "draft" on first transitions read).

**How to apply:** do NOT add `status=` filtering or `listByStatus` for architecture without first adding a real status mirror column (persistence migration + `_STATUS_MIRROR_MODELS` entry + backfill). The frontend `ArchitectureForm` passes a hardcoded `currentStatus="draft"` fallback because the `ArchitectureElement` TS type has no `status` field — the real state loads from the transitions endpoint. Backend item_type key is `"ArchitectureElement"`; frontend `WorkflowArtifactType` key is `"architecture"` (REST resource `architecture`). Preset key: `architecture_default` (states draft/in_review/approved/deprecated).
