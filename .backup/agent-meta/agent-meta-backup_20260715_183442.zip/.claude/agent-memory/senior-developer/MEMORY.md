# Memory Index

- [Test-Ausführung Backend](project-test-execution.md) — pytest nur im backend-Container (`docker exec ...`); Host-Python/venv scheitern an DB-Host + Deps
