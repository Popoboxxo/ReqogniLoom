---
name: syseng2-auditor-ui-phase3
description: SysEng 2.0 Phase 3 SE-Auditor backend — AuditService facade + Adopt/Modify remediation pattern; REST endpoints; scope boundaries
metadata:
  type: project
---

SysEng 2.0 Phase 3 "Auditor UI" backend built on branch `refactor/syseng-2-0-concept`
(not committed — git agent commits). Wraps the Phase-2 RuleEngine (see
[[syseng2-ruleengine-phase2]]) for the dashboard + Adopt/Modify workflow.

**Why:** Spec is `docs/UMSETZUNGSPLAN_SYSENG_2.0.md` §4 Phase 3. Acceptance: dashboard
shows findings filtered by the workspace's active rigor preset; Adopt creates a correct
TraceLink/field-update proven by a negative→positive regression (finding exists → Adopt →
same re-run no longer reports it).

**Remediation pattern (the architectural core) — how to apply / extend:**
- Analysis (read-only) lives in `traceability/audit/remediation.py` (Layer 1), mirroring
  the rule registry: one `Remediation` subclass per rule_id, self-registered via
  `@register_remediation`; `get_remediation(rule_id)` → instance or None. Each `propose()`
  returns a `RemediationProposal` (frozen dataclass, `to_dict()`), one of three outcomes:
  (a) automatic+deterministic (endpoints straight from the finding), (b) automatic+unique
  candidate (auto-fix iff exactly one plausible target in scope), (c) manual/not-automatic.
- Execution lives ONLY in `application/audit_service.py` (`AuditService._execute_action`,
  Layer 2, ADR-01). Remediations NEVER mutate — they return params; the service applies via
  the existing validated `TraceLinkService.create_trace_link`. Keep this split: adding a
  rule = new Remediation subclass; new fix kind = new `RemediationActionKind` member + one
  executor branch. All endpoints are Artifact ids (every TraceLink endpoint is an Artifact id).
- Implemented automatic: TRACE-P5 (deterministic derives-from child→parent), TRACE-P1
  (unique StakeholderNeed → derives-from), TRACE-P2 (unique ArchitectureElement → allocated-to).
  All other rules (incl. deferred CONS-P9/P10) fall through to a manual proposal by default
  (get_remediation → None), so every rule answers crash-free.

**API surface (for the frontend agent):**
- GET `/api/v1/workspaces/<workspace_id>/audit/?scope=project|document|global&scope_artifact_id=<uuid>`
  → `{tier, scope, counts:{total,blockers,warnings}, findings:[{...finding, index, remediation:{automatic,reason,action_kind,params}}]}`.
  Tier is derived from the workspace preset (NO tier query param by design).
- POST `/api/v1/workspaces/<workspace_id>/audit/remediate/` body `{rule_id, artifact_ids[], scope?, scope_artifact_id?}`
  → 200 `{applied, finding_resolved, created_link_id, proposal}`; 422 when not auto-remediable
  (UI shows "Modify"); 400 bad body; 403 viewer. Views in `rest_api/audit_views.py` (dedicated
  module, NOT views.py — matches settings_views/global_default_views convention; keeps the
  ORM-boundary ratchet in `rest_api/tests/test_architecture.py` at 0 for the new file).

**Non-obvious:** `AuditService.run_audit(workspace_id, ctx, *, tier=None, scopes=None)` — tier
optional, auto-resolved from `presets.services.get_preset(ws).preset` (fallback "standard",
never "minimal"). A fresh workspace is NOT extended, so extended-only rules (TRACE-P5 etc.)
need `switch_preset(ws, "extended")` in tests that hit the endpoint without an explicit tier.

**Pre-existing red test (NOT mine, same as Phase 2):**
`traceability/tests/test_services_facade.py::TestFacadeCoverage::test_coverage_via_facade`
(coverage counts 0 instead of 1 for a verifies-link) — unrelated to audit work.
