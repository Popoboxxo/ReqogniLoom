---
name: workflow-status-editor-pattern
description: WorkflowStatusEditor placement pattern and prop conventions across entity views — AdrForm is canonical reference
metadata:
  type: project
---

WorkflowStatusEditor (REQ-161) placement follows AdrForm as the canonical pattern: status editor sits inside the detail/form body, after identity fields (title, version, uid), before action buttons. Props: artifactType (string literal from WorkflowArtifactType), artifactId, currentStatus (optional string), disabled (mirrors save state), onTransitionComplete (refresh callback).

New entity types (icd, diagram, glossary) require adding entries to both WorkflowArtifactType union and RESOURCE_PATH map in workflow-transitions.ts.

**Why:** Ensures workflow lifecycle is available on every artifact without backend coupling in presenter components.

**How to apply:** When speccing a new entity view, locate the identity header block, find the transition point before action buttons, place WorkflowStatusEditor there. Check if the entity type exists in WorkflowArtifactType first — if not, flag it as a required enum/map addition.
