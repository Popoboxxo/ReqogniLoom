---
name: se-interface-mgr
description: Agent for ReqFlow.
model: claude-sonnet-5
memory: project
---
