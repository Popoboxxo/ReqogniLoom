---
name: project-test-execution
description: How to run backend pytest for ReqFlow — must run inside the backend docker container, not on the host
metadata:
  type: project
---

Backend tests must run inside the running backend container:
`docker exec ai-native-reqflow-poc-backend-1 python -m pytest <paths> -q --tb=short -p no:cacheprovider`

**Why:** `reqflow/settings_test.py` hardcodes `HOST: "postgres"` (docker-internal DNS) and the host Python (3.14, PEP-668 managed) lacks celery/pgvector; a host venv still fails on the DB hostname. `docker compose exec` prints env-var warnings AND hard-fails when the repo has no `.env` file (only `.env.example` is checked in) — so `docker compose exec` is unusable here; use plain `docker exec <container-name>` which talks straight to the already-running container.

**How to apply:** Always verify the backend container is Up first (`docker ps`). The backend bind-mounts the source, so file edits are picked up live (a broken settings.py puts the container in a restart loop). Scope test runs: `application/` + `rest_api/` together take >8 min — run only the affected app's test dirs (llm_adapter + resilience finish in ~15s).
