---
name: workflow-editor-req176-177
description: Workflow Editor Phase 1 (REQ-176 read-only) + Phase 2 (REQ-177 edit mode) — non-obvious model constraints and design decisions
metadata:
  type: project
---

Visual Workflow Editor on branch `feat/ux-review-workflow-editor`. Phase 1 (REQ-176) = read-only graph; Phase 2 (REQ-177) = admin-gated edit mode (add/rename/delete states + transitions, initialize). Design brief: `.claude/3-project/workflow-state-machine-editor-design-brief.md`.

**Why:** the design brief was written assuming a richer backend model than exists; Phase 2 had to reconcile the mock with the real `WorkflowEngineDefinition` model.

**How to apply — load-bearing constraints for future workflow-editor work:**

- **Editing requires the workspace to be on the Extended preset.** All mutations read-modify-write through `WorkflowDefinitionStore.validate_and_persist_custom`, which enforces `get_workflow_configurability(ws) == "full"`. Minimal/Standard tiers → `WorkflowNotConfigurableError` → HTTP 403. This is intentional (REQ-L3-WE001-002), not a bug. Demo/seed workspaces on Standard cannot edit.
- **States are plain strings** (byte-identical to each entity's `Status.choices`). No `type`, `description`, or `position` column. State *type* (initial/active/terminal/error) is DERIVED client-side from topology in `toWorkflowGraph` (`frontend/src/api/workflows.ts`). Do NOT try to persist type/description server-side without a schema change.
- **Transitions store only** `from_state, to_state, allowed_roles, requires_change_reason, signature_gate`. No transition *name* — the edge label is derived as `from → to`. Backend always re-adds `"admin"` to `allowed_roles`.
- **Identity in the REST/editor layer:** state id = the state name (URL-encoded); transition id = `<from>__<to>`. `__` is a reserved separator — the store rejects state names containing it.
- **Node positions are client-side only** (`localStorage`, keyed per workspace+entityType, `layout-store.ts`) — deliberate deviation, documented, because the model has no coordinates and layout is a per-user presentation concern.
- **Delete-state rules:** blocked (409) if any transition references it OR any live `WorkflowItemState` sits in it. "initial" state is positional (`states[0]`), so it is auto-single; a wired state can't be deleted, which protects it.
- **Backend layering:** `definition_store.py` granular methods → `workflow/services.py` `*_definition_*` wrappers (remap preset gate, invalidate validator cache) → `WorkflowFacade` methods (set tenant, audit) → `WorkflowDefinitionViewSet` `@action` routes under `/api/v1/workflows/definition/{states,transitions,initialize}/`. Admin gate + 409/403/400 mapping live in the view.
- **Audit:** facade edits write `AuditEntry(op="update", entity_type="WorkflowDefinition:<Type>", entity_id=<workspace_uuid>)`. `op` MUST be in `AuditEntry.OP_CHOICES` (see [[req165-166-workflow-engine-pr-split]] for the prior invalid-op bug); an end-to-end facade test guards this because view tests mock the facade.

**REQ-IDs:** register (`docs/REQUIREMENTS.md`) previously ended at REQ-174; REQ-175/176 were used in commits but never added. Added REQ-176 + REQ-177 rows during Phase 2. Nothing pushed — commits stay local pending user confirmation.
