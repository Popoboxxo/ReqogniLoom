---
name: se-testreviewer
description: Agent for ReqFlow.
model: claude-opus-4-8
permissionMode: plan
---
