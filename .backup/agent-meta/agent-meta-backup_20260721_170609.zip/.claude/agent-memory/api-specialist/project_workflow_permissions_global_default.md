---
name: project_workflow_permissions_global_default
description: REQ-178..187 global-default/override/reset API contract for workflows + permissions (2026-07-18), incl. capability keys and open schema gap
metadata:
  type: project
---

Designed the REST contract for REQ-178–187 (global-default + workspace-override + reset model for Workflow Definitions and Permissions, plus a shadow-rollout for replacing the hardcoded UserRole/ItemPermission RBAC check). Contract file:
`docs/api/workflow-permissions-global-default.openapi.yaml` (OpenAPI 3.1, validated with `openapi-spec-validator`).

**Why:** database-engineer finalized the schema first (`backend/workflow/models.py: GlobalWorkflowDefinition`, `backend/auth_tenancy/models.py: GlobalPermissionDefinition/WorkspacePermissionDefinition/PermissionDecisionMismatch`) and left two open API-design calls for api-specialist to resolve: the `subject_identifier` string format, and the canonical capability key set.

**Key decisions (How to apply — reuse these if this area comes up again):**
- Canonical capability keys = the 6 existing `Operation` enum values from `auth_tenancy/services/authorization.py` (`read`, `write`, `workflow_transition`, `workflow_approval`, `workspace_config`, `assign_role`) — a 1:1 lift, no new capabilities invented. `permission_json` matrix is a closed 4 roles (admin/editor/viewer/approver) × 6 capabilities object, `additionalProperties: false` at both levels.
- `subject_identifier` (on `PermissionDecisionMismatch`) format: `"<type>:<id>"` with `user:<uuid>` (default, JWT/session auth), `apikey:<uuid>` (API-key auth, references `ApiKey.id` not the owning user, for machine/agent-traffic triage), and a reserved-but-unused `agent:<string>` prefix for future non-User/non-ApiKey identities.
- New tenant-wide "global default" resources use FLAT top-level URL paths (`/api/v1/workflow-defaults/`, `/api/v1/permission-defaults/`, `/api/v1/permission-mismatches/`) — matching the existing sibling convention (`/llm-settings/`, `/prompt-templates/`), NOT nested under a `/system-settings/` prefix. REQ-184's "System Settings" IA split is a frontend nav/routing concern only, not an API namespace requirement.
- Existing workspace-level workflow-definition endpoints (`/api/v1/workflows/definition/...`, `WorkflowDefinitionViewSet`) were reused unchanged (REQ-179 regression protection) — only additive response fields (`is_customized`, `source_global_id`, `on_default`) plus one new action `POST /workflows/definition/reset/`. Same pattern applied on the permissions side as an entirely NEW resource `/workspaces/{id}/permission-definition/`, kept distinct from the existing, unchanged `/workspaces/{id}/permissions/` (ItemPermission per-user/per-artifact CRUD, COMP-AT-005) — do not conflate the two when touching this area again.
- Reset-to-default action pattern (`POST .../reset/`) mirrors the pre-existing `PromptTemplateResetView` (`rest_api/settings_views.py`) convention already in the codebase.

**Flagged schema gap (unresolved, non-blocking):** `PermissionDecisionMismatch` has no per-row triage/acknowledgement field (no `reviewed_at`/`reviewed_by`). REQ-187 allows "zero mismatches OR explicitly reviewed-and-accepted" as the cutover gate, but only the first is precisely expressible today. Interim guard (no schema change): the `POST /permission-defaults/enforcement/flip/` endpoint requires the caller to echo the exact current `pending_mismatch_count` — a stale echo is rejected (409), forcing a fresh look immediately before flipping shadow→authoritative. Recommended follow-up for database-engineer: add `reviewed_at`/`reviewed_by` to `PermissionDecisionMismatch` for true per-row triage. See `x-schema-gap-flip-guard` in the contract file for full detail.

**MCP note:** new REST surface has no MCP tool-group counterpart yet; flagged as a follow-up (extend an existing tool group, e.g. `workflow`/`permissions`), not required for this task.
