# Memory Index

- [REQ-ID-Ledger](project_req_id_ledger.md) — aktueller Höchststand & bekannte Lücken in docs/REQUIREMENTS.md, immer gegen Datei verifizieren
- [Next-Free-ID immer aus Datei lesen](feedback_verify_next_id_from_file.md) — Cross-Chat-Memory-Notizen zur nächsten freien REQ-ID waren veraltet, Datei ist einzige Quelle
- [Workflow/Permissions Global-Default-Redesign](project_workflow_permissions_global_default.md) — REQ-178–187 (inkl. Permission-Modernisierung/Legacy-Ablösung REQ-186/187), Kontext & offene Abhängigkeiten für Folge-Agenten
