---
name: syseng2-architecture-role-derivation
description: SysEng 2.0 — ArchitectureElement role (System/Subsystem/Component) is derived from tree position, not stored; new I5 single-root invariant
metadata:
  type: project
---

SysEng 2.0 §1.2 (docs/UMSETZUNGSPLAN_SYSENG_2.0.md): the architectural *role* of an
ArchitectureElement is derived at runtime from its tree position, never stored.

- root (no parent) → **system** (root beats leaf: a lone node is a System)
- inner node (has non-deleted children) → **subsystem**
- leaf → **component**

**Why:** the stored free-text `element_type` field proved unreliable as role authority
(the "Banane" problem — arbitrary values). `element_type` is intentionally KEPT as a
free-text descriptive tag but is NO LONGER the role authority — do not wire it back.

**How to apply:**
- SSOT mapping: `persistence.models.derive_architecture_role(has_parent, has_children)`.
- Model exposes `ArchitectureRole` enum + `role` property (`_role_annotated` bulk value,
  else `get_role()` single-instance = one EXISTS query).
- Bulk derivation: `ArchitectureService._annotate_roles` — single in-memory pass mirroring
  the existing `_annotate_levels`. Deliberately NOT the CTE `get_with_level()`; the codebase
  already prefers in-memory annotation over the CTE to avoid N+1 (REQ-070).
- REST: `ArchitectureElementSerializer.role` (read-only CharField); `_arch_to_dict` fills it.
- Reparenting (drag&drop / update_architecture_element parent_id) changes the role
  automatically because it is computed — no data migration, no field update.

**New invariant I5 (single root per workspace)** in `application/validators.py`:
- "at most one root (System) per workspace"; the workspace IS the tree scope
  (ArchitectureElement is scoped via artifact.workspace_id).
- Enforced on ALL rigor tiers (minimal/standard/extended), unlike I1/I2/I4 — because the
  role model names the unique root the "System" regardless of preset. `ALL_INVARIANTS` and
  `RIGOR_INVARIANT_PRESETS` now include I5.
- Authoritative enforcement is in the SERVICE (`create_architecture_element` runs the
  validator for roots too; `update_architecture_element` runs it on any parent_id change
  incl. detach-to-root). The serializer path does NOT enforce I5. Existing data with
  multiple roots is not retroactively rejected — only NEW root creation/detach is gated.
- Element under validation is excluded from the root scan via `element_id` (re-saving the
  existing root as root stays valid).

Frontend: `ArchitectureForm.tsx` shows role as a read-only display (`data-testid=arch-role-display`),
NOT an editable dropdown; `arch.role` / `arch.roleValue.*` i18n keys (de/en).

Pre-existing broken tests unrelated to this work: `mcp_server/tests/test_e2e_all_tools.py`
errors with `UserManager has no attribute create_superuser` (pytest-django `admin_user`
fixture incompatible with the custom User manager). Full-suite `--create-db` also flakes with
`column "password" of relation "pl_user" already exists`; use `--reuse-db`.
