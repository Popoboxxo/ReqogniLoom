---
name: project-workflow-permissions-global-default-ui
description: UI spec for REQ-178..187 (Global-Default workflow/permission model + Settings IA split) — screen inventory, reuse plan, pending user confirmation
metadata:
  type: project
---

Full UI spec written 2026-07-18 at `docs/ui/workflow-permissions-global-default-ui-spec.md` on branch `feat/ux-review-workflow-editor`, covering REQ-178 through REQ-187. Step 4 of a 7-step pipeline (requirements → database-engineer → api-specialist → ui-ux-designer → senior-developer → validator → git); schema and API contract (`docs/api/workflow-permissions-global-default.openapi.yaml`) were already finalized when this spec was written.

Key decisions:
- New top-level nav entry "System Settings" at `/system-settings`, inserted immediately after the existing "Settings" nav item — admin-gated at the page level (same pattern as `/settings`), not at the nav-link level.
- `/settings` keeps general/traceability/visibility/llm tabs unchanged; its "admin" tab (System Health + Workspace Lifecycle + BackupRestore) relocates verbatim to `/system-settings` → "Administration" tab (REQ-184 says so explicitly, even though workspace lifecycle actions are workspace-scoped — not re-litigated, followed as specified).
- The old "governance" tab (`WorkflowsSection.tsx` + `PermissionsSection`) is rebuilt into a "Workflows & Permissions" tab showing on-default/customized badges + reset-to-default per entity type (workflow) and for the permission matrix, per [[workflow_status_editor_pattern]]-adjacent conventions but new (`DefaultStatusBadge` component).
- `WorkflowsSection.tsx` is proposed for full deletion (only consumer is the governance tab, functionality superseded by `WorkflowStatusEditor` + `/workflows/:entityType`) — flagged for explicit user confirmation, NOT yet approved for execution by senior-developer.
- `PermissionsSection` (ItemPermission per-user/per-artifact CRUD) is relocated unchanged, not deleted — distinct resource from the new permission-matrix override (REQ-182 protects it explicitly).
- Global workflow-defaults editor (System Settings → "Workflow Defaults" tab) reuses `WorkflowEditorPage`/`WorkflowEditorHeader`/`WorkflowCanvas`/etc. as-is via a new `scope: workspace|global` parameterization — only new control added is a `PresetSegmentedControl` (minimal/standard/extended), since global defaults are per-(item_type, preset) unlike a workspace which has one preset.
- Permission enforcement flip (shadow→authoritative, REQ-186/187) is guarded by a dialog that re-fetches the live pending-mismatch count, requires a checkbox acknowledgment, and echoes `confirm_pending_mismatch_count` — schema has no per-row triage field yet (api-specialist flagged this as `x-schema-gap-flip-guard`), so this is the best available guard until a future `reviewed_at`/`reviewed_by` field lands.

**Why:** Recorded so senior-developer/validator/git steps (and any future revisit of this feature) don't need to re-derive the reuse/relocation boundaries or re-discover which deletion still needs user sign-off.

**How to apply:** Before touching `WorkspaceSettings.tsx`, `WorkflowsSection.tsx`, `PermissionsSection.tsx`, or `WorkflowEditor/*` on this or a follow-up branch, check this memory and the spec file first — don't re-derive the IA split from scratch. If the user has since confirmed the `WorkflowsSection.tsx` deletion, update this memory to drop the "not yet approved" caveat.
