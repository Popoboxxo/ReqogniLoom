---
name: workflow-permissions-global-default-ui
description: Frontend of the global-default/override/reset model + Settings IA-split (REQ-178..187) — scope-parameterization pattern, IA move, pre-existing test flakes
metadata:
  type: project
---

Frontend half (pipeline step 5/7) of the Workflow & Permissions Global-Default model + Settings-IA-split, branch `feat/ux-review-workflow-editor`. Spec: `docs/ui/workflow-permissions-global-default-ui-spec.md`; contract: `docs/api/workflow-permissions-global-default.openapi.yaml`; reqs REQ-178..187 in `docs/REQUIREMENTS.md`.

**Why:** user feedback on REQ-176 ("data model is wrong") — workflows/permissions were workspace-only with no tenant-wide default/inherit/reset. New symmetric global→override→reset model for both, plus a Workspace-Settings vs System-Settings split.

**How to apply — load-bearing decisions:**

- **`WorkflowEditorPage` is scope-parameterized, NOT forked.** A `scope?: "workspace" | "global"` prop drives everything. `useWorkflowData`/`useWorkflowMutations`/`EntityTypeSelector` take a `WorkflowScope` union (`constants.ts`): `{kind:"workspace",workspaceId}` or `{kind:"global",preset}`. Workspace scope = unchanged behaviour (REQ-179 regression protection); global scope reads `/workflow-defaults/{item_type}/{preset}/...` via `api/workflow-defaults.ts` and threads `propagated_workspace_count` to a toast. TanStack cache key = `scopeCacheKey(scope)` (`ws:<id>` or `global:<preset>`). Global scope keeps entityType+preset in query params (`?entityType&preset`), no new route segments.
- **IA split (REQ-184):** `/settings` (WorkspaceSettings) lost its **admin** tab and its **governance** tab. Governance → rebuilt as `workflows-permissions` tab (`WorkflowPermissionsSection` = on-default/customized badges + reset per entity type + permission matrix override; the existing `PermissionsSection` ItemPermission CRUD renders unchanged below it per REQ-182). Admin tab content (SystemHealth + Backup + lifecycle close/delete/clone) was **extracted verbatim** into `components/SystemSettings/WorkspaceAdminSection.tsx` — it still operates on `useWorkspace().activeWorkspace` (workspace switcher is global, not route-scoped). New route `/system-settings` (`SystemSettings.tsx`, admin-gated via page-level early-return, nav link always visible like `/settings`).
- **`WorkflowsSection.tsx` was DELETED** (user-approved) — legacy raw-artifact-id form, fully superseded. No dedicated test existed; only a mock in `WorkspaceSettings.test.tsx` (updated).
- **Enforcement flip guard (REQ-187):** `EnforcementFlipDialog` reuses the editor's `ConfirmDialog` (extended with a `children` slot + `confirmDisabled`), re-fetches the live `pending_mismatch_count` on open, requires an ack checkbox, echoes the exact count as `confirm_pending_mismatch_count`; on 409 MISMATCH_COUNT_STALE it shows the fresh count and forces re-confirm (`extractStaleMismatchCount`). Rollback authoritative→shadow is a plain `window.confirm`, no count gate.
- **Contract tolerance:** the OpenAPI workflow state/transition mutation responses are typed as `WorkflowGraphGlobal` WITHOUT `propagated_workspace_count`, but the UI spec asks to surface it. `api/workflow-defaults.ts` reads it as OPTIONAL — toasts when present, silent when absent. Intentional, documented in the file header.
- **i18n:** new nav labels use a real JSON key `nav.systemSettings` (nav uses `t(key)` with no fallback); everything else uses inline `t(key, "English fallback")` (the codebase pattern — `settings.tabs.*` have no JSON entries).

**Pre-existing test flakes (NOT regressions):** the full `vitest run` shows 2 failures — `TestRuns/TestRunsList.test.tsx` and `test/AdrEditors.test.tsx` (raw i18n keys rendered: "You will need to pass in an i18next instance"). Verified via `git stash -u` that both fail IDENTICALLY on HEAD without any of this work. Do not chase these when validating this feature. The full suite is also very slow (~10 min) — prefer focused `vitest run <file>`.
