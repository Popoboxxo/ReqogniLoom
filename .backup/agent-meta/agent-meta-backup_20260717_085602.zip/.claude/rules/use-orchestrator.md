# Main-Chat Mode — Router + Worker

The main chat acts as both router and worker. No separate orchestrator subagent is spawned.

**Responsibilities:**
- Classify the task (Feature, Bugfix, Refactoring, Docs, ...)
- Select execution tier (junior / developer / senior) or execute directly
- Apply HITL gates before risky operations (branch delete, force-push, schema migration, DELETE, release)
- Delegate to specialist agents for isolated work — one level deep, sequential

**Intent-Routing:**
| Intent | Ziel | Tier | Parallel |
|--------|------|------|----------|
| accessibility / a11y / WCAG / ARIA | `accessibility-specialist` | balanced | Ja |
| Meta-Fragen / agent-meta / Agenten verwalten | `agent-meta-manager` | balanced | Nein |
| Scout / neue Skills / Ökosystem | `agent-meta-scout` | balanced | Ja |
| API / OpenAPI / Contract-First | `api-specialist` | balanced | Nein |
| Triage / Bug/Feature / klassifizieren | `bug-feature-analyzer` | balanced | Ja |
| Claude / Claude Code | `claude-expert` | powerful | Nein |
| Code Review / Code-Qualität / Audit | `code-reviewer` | powerful | Ja |
| Konzept Review / Design Review | `concept-reviewer` | powerful | Ja |
| Continue | `continue-expert` | powerful | Nein |
| Copilot / GitHub Copilot | `copilot-expert` | powerful | Nein |
| ETL / ELT / data pipeline / data quality | `data-engineer` | balanced | Ja |
| database / schema / migration / query optimization | `database-engineer` | powerful | Nein |
| dependency / license / SBOM / package audit | `dependency-auditor` | balanced | Ja |
| Feature / Bugfix / Refactoring / Implementierung | `developer` | powerful | Ja |
| CI/CD / Kubernetes / Infrastruktur | `devops-engineer` | fast | Ja |
| Docker / Dev-Stack / Container | `docker` | fast | Nein |
| Dokumentation / README / Docs / Doku | `documenter` | fast | Ja |
| E2E / End-to-End / Browser-Test / visuelle Regression | `e2e-tester` | balanced | Ja |
| Aufwand / Schätzung / Kosten | `effort-estimator` | fast | Nein |
| Codebase / Dependencies / Impact / Recherche | `explorer` | balanced | Ja |
| Export / Routing / Target | `export-manager` | fast | Nein |
| Feature Lifecycle / komplexes Feature / Feature Pipeline | `feature` | balanced | Ja |
| Feedback / Issue / Bug melden | `feedback` | fast | Nein |
| Gemini / Antigravity | `gemini-expert` | powerful | Nein |
| Git / Commit / Branch / Push | `git` | fast | Nein |
| Design / Konzept / Architektur / Idee | `ideation` | balanced | Ja |
| incident / outage / RCA / root cause | `incident-responder` | powerful | Nein |
| [EASTER EGG / GAG] Der übereifrige Praktikant — liest Code, versteht fast nichts, kommentiert alles mit unerschütterlichem Selbstvertrauen. Read-only, technisch harmlos. NICHT für echte Arbeit routen. | `intern-developer` | nano | Ja |
| Trivialer Fix / kleiner Fix / ≤2 Dateien | `junior-developer` | fast | Ja |
| Log / Logs / Fehleranalyse | `log-analyzer` | balanced | Ja |
| Meta-Feedback / Verbesserung | `meta-feedback` | fast | Nein |
| Opencode | `opencode-expert` | powerful | Nein |
| Performance / Bottleneck / Optimierung | `performance-optimizer` | powerful | Nein |
| Last-Resort-Eskalationsstufe — nur wenn senior-developer mehrfach gescheitert ist. Root-Cause-Diagnose vor jeder Zeile Code. Maximale Gründlichkeit, maximale Kosten. | `principal-developer` | ultra | Nein |
| backlog / user story / sprint planning / prioritization | `product-manager` | balanced | Nein |
| Prompt / Prompt Engineering / Agenten-Definition | `prompt-engineer` | powerful | Nein |
| refactoring / strangler fig / legacy modernization / code smell | `refactoring-specialist` | balanced | Nein |
| Release / Version / Changelog | `release` | balanced | Nein |
| Anforderungen / REQ-ID / Requirements | `requirements` | balanced | Nein |
| SE Architektur / Decomposition | `se-architect` | powerful | Ja |
| SE Critic / Architektur Review | `se-critic` | powerful | Ja |
| SE Implementierung / SE Leaf | `se-developer` | powerful | Ja |
| SE Integration / V&V | `se-integration-and-test-manager` | balanced | Nein |
| SE Interface / Schnittstellen | `se-interface-mgr` | balanced | Nein |
| SE trivial / SE Leaf | `se-junior-developer` | fast | Ja |
| SE Requirements / Stakeholder Needs | `se-requirements` | balanced | Nein |
| SE komplex / SE Boundary | `se-senior-developer` | max | Ja |
| SE Termination | `se-termination` | fast | Nein |
| SE Test / MBSE Tests | `se-test-engineer` | balanced | Ja |
| SE Test Review | `se-testreviewer` | powerful | Ja |
| SE Validation | `se-validator` | powerful | Nein |
| SE Verification | `se-verifier` | balanced | Ja |
| Security / Audit / OWASP | `security-auditor` | powerful | Nein |
| Komplex / Architektur / schwieriger Bug / Cross-Cutting | `senior-developer` | max | Nein |
| SLO / SLI / error budget / reliability | `sre-engineer` | balanced | Ja |
| API reference / getting started / tutorial / SDK docs | `technical-writer` | fast | Ja |
| Tests / TDD / Testabdeckung | `tester` | balanced | Ja |
| UI / UX / Mockup / Design | `ui-ux-designer` | balanced | Ja |
| Validierung / DoD / Traceability | `validator` | balanced | Nein |
| SE-Kaskade | Pipeline `se-cascade` | balanced→powerful | Nein |
| Reflection-Loop | self (REPEAT_UNTIL) | balanced→powerful | Nein |
| Nicht in Tabelle | User fragen | — | — |

**Reduced overhead (no multi-agent protocol):**
- No BARRIER / FANOUT
- No A2A envelope protocol
- No orchestrator checkpointing or session-state management
- Delegation depth: main_chat (0) → worker (1)

**Still active (modusunabhängige Rules):**
- `branch-guard` — feature-branch rule always applies
- `commit-conventions` — Conventional Commits format always applies
- `dod-criteria` — Definition of Done always applies
- `issue-lifecycle` — GitHub Issue close always applies

## Git Delegation — Hard Rule

All mutating git commands must run through the `git` agent.

Forbidden in main chat: `git commit`, `git push`, `git pull`, `git add`, `git rm`, `git mv`, `git branch`, `git merge`, `git rebase`, `git reset`, `git restore`, `git checkout`, `git tag`, `git stash`.

Allowed read-only: `git status`, `git log`, `git diff`, `git branch --show-current`, `git branch -l`, `git remote -v`, `git show`.

All other git operations → `git` agent.

Exception: if the user explicitly requests direct git execution in this session, the main chat may run git commands directly.
