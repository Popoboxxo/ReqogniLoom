# Memory Index

- [Workflow & Permissions Global-Default API Contract](project_workflow_permissions_global_default.md) — REQ-178..187: capability keys, subject_identifier format, URL conventions, flagged schema gap
