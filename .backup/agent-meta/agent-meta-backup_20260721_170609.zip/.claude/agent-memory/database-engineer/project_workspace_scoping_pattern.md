---
name: workspace-scoping-pattern
description: How ReqFlow scopes artifact tables to a workspace — decoupled UUIDField, not a cross-app FK
metadata:
  type: project
---

ReqFlow artifact models scope to a workspace with a **decoupled `workspace_id = models.UUIDField(...)`**, NOT a Django `ForeignKey` to `persistence.Workspace`. Reference implementation: `Icd.workspace_id` (backend/icd/models.py) with a named index `idx_icd_workspace`. `Diagram` follows the same pattern as of REQ-173 (`idx_diagram_workspace`).

**Why:** avoids coupling feature apps (icd, diagram) to the persistence app's Workspace table. A real `Workspace` model does exist at `persistence/models.py` (~line 444), but artifact apps intentionally do not FK to it.

**How to apply:** when a task says "add a workspace FK" to an artifact model, implement it as a `UUIDField` mirroring `Icd.workspace_id` — a real FK would break the established decoupling. Note: `Icd` declares BOTH `db_index=True` on the field AND a named Meta index (redundant double index); prefer only the named Meta index to avoid the redundancy. See [[db-ops-environment]] for how to verify indexes.
